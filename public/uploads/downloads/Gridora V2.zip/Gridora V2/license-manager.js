(function(){
var _0x9f1a = ['dXNlIHN0cmljdA==','dW5kZWZpbmVk','ZmlsZTo=','Y2hyb21l','bnVsbA==','aHR0cHM6Ly9iaWQwMzIuY29t','ZnVuY3Rpb24=','dXhw','Y2hpbGRfcHJvY2Vzcw==','d2luMzI=','c3RhcnQgIiIgIg==','L2csICdcXA==','KSArIA==','ICsgdXJsLnJlcGxhY2UoLyIvZywg','JykgKyAn','ICYmIHdpbmRvdy5DU0ludGVyZmFjZSkgPyB3aW5kb3cuQ1NJbnRlcmZhY2UgOiAodHlwZW9mIENTSW50ZXJmYWNlICE9PSA=','KSAhPT0gLTEgfHwgdGFyZ2V0VXJsLmluZGV4T2Yo','ICYmIHR5cGVvZiB3aW5kb3cucmVxdWlyZSA9PT0g','KSA6IHdpbmRvdy5yZXF1aXJlKA==','ICsgRGF0ZS5ub3coKS50b1N0cmluZygzNikgKyA=','ICYmIGNoaWxkLnRhZ05hbWUgIT09IA==','LCBjaGlsZC5zdHlsZS5kaXNwbGF5IHx8IA==','ICYmIGNoaWxkLmhhc0F0dHJpYnV0ZSg=','IHx8IG9yaWdEaXNwbGF5ID09PSA=','KSA/IA==','IHx8IGNhY2hlZFNlc3Npb24gPT09IA==','LCBwbGFuX25hbWU6IA==','KS5yZXBsYWNlKC9bXkEtWmEtejAtOV0vZywg','ICsgKG5hdmlnYXRvci5wbGF0Zm9ybSB8fCA=','IDog','cmstZm9vdGVyLW5vdGU=','cmstYnV5LWJ0bg==','Y2xpY2s=','cmsta2V5LWlucHV0','aW5wdXQ=','a2V5cHJlc3M=','RW50ZXI=','cmstYWN0aXZhdGUtYnRu','cmstbW9kYWwtb3ZlcmxheQ==','ZGl2','cG9zaXRpb246Zml4ZWQgIWltcG9ydGFudDsgdG9wOjAgIWltcG9ydGFudDsgbGVmdDowICFpbXBvcnRhbnQ7IHJpZ2h0OjAgIWltcG9ydGFudDsgYm90dG9tOjAgIWltcG9ydGFudDsgd2lkdGg6MTAwJSAhaW1wb3J0YW50OyBoZWlnaHQ6MTAwJSAhaW1wb3J0YW50OyBiYWNrZ3JvdW5kOiMxNDE0MTQgIWltcG9ydGFudDsgZGlzcGxheTpmbGV4ICFpbXBvcnRhbnQ7IGFsaWduLWl0ZW1zOmNlbnRlciAhaW1wb3J0YW50OyBqdXN0aWZ5LWNvbnRlbnQ6Y2VudGVyICFpbXBvcnRhbnQ7IHotaW5kZXg6OTk5OTk5OTkgIWltcG9ydGFudDsgcGFkZGluZzoxNnB4ICFpbXBvcnRhbnQ7IGJveC1zaXppbmc6Ym9yZGVyLWJveCAhaW1wb3J0YW50Ow==','cmtfZ2xvYmFsX2V4cGlyZXNfbXM=','TGlmZXRpbWUgQWNjZXNz','R3JpZG9yYQ==','U3RhbmRhcmQgTGljZW5zZQ==','4oCi4oCi4oCi4oCi','cmstY2FyZA==','cmstaGVhZGVy','cmstYmFkZ2U=','YmFja2dyb3VuZDogcmdiYSgzNCwgMTk3LCA5NCwgMC4xNSk7IGNvbG9yOiAjNGFkZTgwOyBib3JkZXItY29sb3I6IHJnYmEoMzQsIDE5NywgOTQsIDAuNCk7','cmstdGl0bGU=','cmstc3VidGl0bGU=','cmstaW5mby1ncmlk','cmstaW5mby1yb3c=','cmstaW5mby1sYWJlbA==','cmstaW5mby12YWw=','Y29sb3I6ICNmNTdmMDA7','cmstaW5mby12YWwgcmsta2V5LXZhbA==','cmstY291bnRkb3duLXRpbWVy','cmstaW5mby12YWwgcmstdGltZXItdmFs','cmstY29udGludWUtYnRu','cmstYnRuLXByaW1hcnk=','YnV0dG9u','bWFyZ2luLXRvcDogNHB4Ow==','cmstdW5iaW5kLWJ0bg==','cmstYnRuLXNlY29uZGFyeQ==','TGlmZXRpbWUgQWNjZXNzIChOZXZlciBFeHBpcmVzKQ==','IzM4YmRmOA==','cmtfZ2xvYmFsX3Nlc3Npb24=','cmtfZ2xvYmFsX2tleQ==','cmtfZ2xvYmFsX2V4cGlyZXNfYXQ=','WW91ciBsaWNlbnNlIGtleSBoYXMgZXhwaXJlZC4gUGxlYXNlIGVudGVyIGEgdmFsaWQgbGljZW5zZSBrZXkgdG8gY29udGludWUu','cmstZXJyb3ItYm94','YmxvY2s=','W0JpZDAzMiBMaWNlbnNlXSBHcmlkb3JhIGxpY2Vuc2UgaW5pdGlhbGl6ZWQgYW5kIHZhbGlkYXRlZCBzdWNjZXNzZnVsbHk6','Y29tcGxldGU=','aW50ZXJhY3RpdmU=','RE9NQ29udGVudExvYWRlZA==','bGljZW5zZUJ0bg==','I2xpY2Vuc2VCdG4='];
function _0x3b1c(idx) {
  var b64 = _0x9f1a[idx];
  if (!b64) return '';
  try {
    return decodeURIComponent(escape(atob(b64)));
  } catch(e) {
    try {
      return atob(b64);
    } catch(err) {
      return b64;
    }
  }
}
(function(){
  var _rot = function(arr, count) {
    while (count--) { arr.push(arr.shift()); }
  };
  _rot(_0x9f1a, 0x17);
})();
(function _0xcheckIntegrity() {
  var _v = function() {
    if (typeof document !== 'undefined') {
      var scripts = document.getElementsByTagName('script');
      var found = false;
      for (var i = 0; i < scripts.length; i++) {
        if (scripts[i].src && scripts[i].src.indexOf('license-manager.js') !== -1) {
          found = true;
          break;
        }
      }
    }
  };
  try { _v(); } catch(e){}
  setInterval(_v, 5000);
})();
(function (global) {
  _0x3b1c(0x0);
  var DEFAULT_STORE_URL = (function () {
    if (typeof window !== _0x3b1c(0x1) && window.location && window.location.origin) {
      var origin = String(window.location.origin || '').toLowerCase();
      if (origin && !origin.startsWith(_0x3b1c(0x2)) && !origin.startsWith(_0x3b1c(0x3)) && origin !== _0x3b1c(0x4)) {
        return window.location.origin;
      }
    }
    return _0x3b1c(0x5);
  })();
  function openExternalUrl(url) {
    if (!url) return;
    try {
      var reqFn = (typeof require === _0x3b1c(0x6)) ? require : (typeof window !== _0x3b1c(0x1) && typeof window.require === _0x3b1c(0x6) ? window.require : null);
      if (reqFn) {
        var uxp = reqFn(_0x3b1c(0x7));
        if (uxp && uxp.shell && typeof uxp.shell.openExternal === _0x3b1c(0x6)) {
          uxp.shell.openExternal(url);
          return;
        }
      }
    } catch (e) {}
    if (typeof window !== _0x3b1c(0x1) && window.cep && window.cep.util && typeof window.cep.util.openURLInDefaultBrowser === _0x3b1c(0x6)) {
      try {
        window.cep.util.openURLInDefaultBrowser(url);
        return;
      } catch (e) {}
    }
    try {
      var reqFn2 = (typeof require === _0x3b1c(0x6)) ? require : (typeof window !== _0x3b1c(0x1) && typeof window.require === _0x3b1c(0x6) ? window.require : null);
      if (reqFn2) {
        var cp = reqFn2(_0x3b1c(0x8));
        if (cp && typeof cp.exec === _0x3b1c(0x6)) {
          var platform = (typeof process !== _0x3b1c(0x1) && process.platform) || _0x3b1c(0x9);
          if (platform === _0x3b1c(0x9)) {
            cp.exec(_0x3b1c(0xa) + url.replace(/_0x3b1c(0xb)_0x3b1c(0xc)"');
            return;
          } else if (platform === 'darwin') {
            cp.exec('open "_0x3b1c(0xd)\\_0x3b1c(0xe)');
            return;
          }
        }
      }
    } catch (e) {}
    try {
      var CS = (typeof window !== 'undefined_0x3b1c(0xf)undefined' ? CSInterface : null);
      if (CS) {
        var csInstance = new CS();
        if (csInstance && typeof csInstance.openURLInDefaultBrowser === 'function') {
          csInstance.openURLInDefaultBrowser(url);
          return;
        }
      }
    } catch (e) {}
    try {
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch (e) {}
  }
  function sendPostRequest(url, payload, callback, isRetry) {
    var targetUrl = url;
    function handleFallback(err) {
      if (!isRetry) {
        var fallbackUrl = null;
        if (targetUrl.indexOf('bid032.com') !== -1) {
          fallbackUrl = targetUrl.replace('https:
        } else if (targetUrl.indexOf('localhost:3000_0x3b1c(0x10)127.0.0.1:3000') !== -1) {
          fallbackUrl = targetUrl.replace(/http:\/\/(localhost|127\.0\.0\.1):3000/, 'https:
        }
        if (fallbackUrl) {
          sendPostRequest(fallbackUrl, payload, function (fbErr, fbData) {
            if (!fbErr && fbData) {
              var newStoreUrl = fallbackUrl.substring(0, fallbackUrl.indexOf('/api/'));
              if (global.Bid032License && global.Bid032License.config) {
                global.Bid032License.config.storeUrl = newStoreUrl;
              }
              callback(null, fbData);
            } else {
              callback(err, null);
            }
          }, true);
          return;
        }
      }
      callback(err, null);
    }
    if (typeof window !== 'undefined_0x3b1c(0x11)function') {
      try {
        var parsedUrl = new URL(targetUrl);
        var isHttps = parsedUrl.protocol === 'https:';
        var httpModule = isHttps ? window.require('https_0x3b1c(0x12)http');
        var postData = JSON.stringify(payload);
        var hostname = parsedUrl.hostname;
        if (hostname === 'localhost') {
          hostname = '127.0.0.1';
        }
        var reqOptions = {
          hostname: hostname,
          port: parsedUrl.port || (isHttps ? 443 : 80),
          path: parsedUrl.pathname + parsedUrl.search,
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(postData),
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) CEP/11.0 Bid032LicenseSDK'
          },
          timeout: 5000
        };
        var req = httpModule.request(reqOptions, function (res) {
          var body = '';
          res.on('data', function (chunk) { body += chunk; });
          res.on('end', function () {
            try {
              var json = JSON.parse(body);
              callback(null, json);
            } catch (err) {
              callback(new Error('Server returned invalid response format.'));
            }
          });
        });
        req.on('timeout', function () {
          req.destroy();
        });
        req.on('error', function (err) {
          handleFallback(err);
        });
        req.write(postData);
        req.end();
        return;
      } catch (e) {
      }
    }
    var controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timeoutId = controller ? setTimeout(function () { controller.abort(); }, 5000) : null;
    fetch(targetUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      signal: controller ? controller.signal : undefined
    })
      .then(function (res) {
        if (timeoutId) clearTimeout(timeoutId);
        return res.json().catch(function () {
          throw new Error('Server returned invalid response.');
        });
      })
      .then(function (data) {
        callback(null, data);
      })
      .catch(function (err) {
        if (timeoutId) clearTimeout(timeoutId);
        handleFallback(err);
      });
  }
  function generateDeviceFingerprint() {
    var nav = global.navigator || {};
    var screen = global.screen || {};
    var str = [
      nav.userAgent || '',
      nav.language || '',
      screen.colorDepth || '',
      screen.width || '',
      screen.height || '',
      new Date().getTimezoneOffset()
    ].join('|');
    var hash = 0;
    for (var i = 0; i < str.length; i++) {
      var char = str.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash |= 0;
    }
    return 'dev_' + Math.abs(hash).toString(36);
  }
  function getInstallationId() {
    var key = 'rk_installation_id';
    var id = localStorage.getItem(key);
    if (!id) {
      id = 'inst__0x3b1c(0x13)_' + Math.random().toString(36).substring(2, 6);
      localStorage.setItem(key, id);
    }
    return id;
  }
  function computeLocalExpiresMs(data) {
    if (!data || !data.expires_at) return null;
    var expiresMs = new Date(data.expires_at).getTime();
    if (isNaN(expiresMs)) {
      expiresMs = new Date(String(data.expires_at).replace(' ', 'T')).getTime();
    }
    if (isNaN(expiresMs)) return null;
    var serverMs = data.server_time ? new Date(data.server_time).getTime() : 0;
    if (isNaN(serverMs) || serverMs <= 0) {
      serverMs = Date.now();
    }
    var remainingMs = expiresMs - serverMs;
    if (remainingMs <= 0) return 0;
    return Date.now() + remainingMs;
  }
  function formatLocalDateTimeSmart(dateInput) {
    if (!dateInput) return 'Lifetime Access';
    var d = (dateInput instanceof Date) ? dateInput : new Date(dateInput);
    if (isNaN(d.getTime())) return 'Lifetime Access';
    var targetOffset = -180; 
    var currentOffset = d.getTimezoneOffset(); 
    var adjustmentMs = (currentOffset - targetOffset) * 60000;
    var adjustedDate = new Date(d.getTime() + adjustmentMs);
    return adjustedDate.toLocaleString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  }
  function injectStyles() {
    var style = document.getElementById('rk-license-styles');
    if (!style) {
      style = document.createElement('style');
      style.id = 'rk-license-styles';
      document.head.appendChild(style);
    }
    style.innerHTML = `
      body.rk-locked > *:not(#rk-modal-overlay) {
        display: none !important;
      }
      .rk-modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        width: 100vw;
        height: 100vh;
        background: rgba(10, 10, 10, 0.95);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 999999999;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        color: #ffffff;
        box-sizing: border-box;
        padding: 16px;
      }
      .rk-card {
        background: #202020;
        border: 1px solid #333333;
        border-radius: 8px;
        width: 100%;
        max-width: 380px;
        padding: 24px 20px;
        box-shadow: 0 12px 40px rgba(0, 0, 0, 0.85);
        box-sizing: border-box;
        position: relative;
        overflow: hidden;
      }
      .rk-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 2px;
        background: #f57f00;
      }
      .rk-header {
        text-align: center;
        margin-bottom: 20px;
      }
      .rk-badge {
        display: inline-block;
        font-size: 9px;
        font-weight: 700;
        letter-spacing: 1px;
        text-transform: uppercase;
        color: #f57f00;
        background: rgba(245, 127, 0, 0.12);
        border: 1px solid rgba(245, 127, 0, 0.3);
        padding: 3px 10px;
        border-radius: 4px;
        margin-bottom: 8px;
      }
      .rk-title {
        font-size: 16px;
        font-weight: 700;
        color: #ffffff;
        margin: 0 0 4px 0;
      }
      .rk-subtitle {
        font-size: 11px;
        color: #888888;
        margin: 0;
        line-height: 1.4;
      }
      .rk-input-group {
        margin-bottom: 18px;
      }
      .rk-label {
        display: block;
        font-size: 9px;
        font-weight: 700;
        color: #888888;
        margin-bottom: 6px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        text-align: left;
      }
      .rk-input {
        width: 100% !important;
        height: 34px !important;
        line-height: 34px !important;
        background: rgba(255, 255, 255, 0.04) !important;
        border: 1px solid #333333 !important;
        border-radius: 6px !important;
        padding: 0 10px !important;
        color: #ffffff !important;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, monospace !important;
        font-size: 12px !important;
        font-weight: 700 !important;
        letter-spacing: 1.5px !important;
        text-align: center !important;
        box-sizing: border-box !important;
        outline: none !important;
        transition: all 0.15s ease !important;
      }
      .rk-input:focus {
        border-color: #f57f00 !important;
        background: rgba(0, 0, 0, 0.3) !important;
        box-shadow: 0 0 0 2px rgba(245, 127, 0, 0.2) !important;
      }
      .rk-input::placeholder {
        color: #666666 !important;
        letter-spacing: 1px !important;
        font-weight: 500 !important;
      }
      .rk-btn-primary {
        width: 100%;
        height: 32px;
        background: linear-gradient(180deg, #f57f00 0%, #cc6a00 100%);
        color: #ffffff;
        font-weight: 700;
        font-size: 11px;
        border-radius: 6px;
        border: 1px solid #b35900;
        cursor: pointer;
        transition: all 0.15s ease;
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2), 0 2px 4px rgba(0, 0, 0, 0.3);
        text-shadow: 0 1px 1px rgba(0, 0, 0, 0.3);
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
      }
      .rk-btn-primary:hover {
        filter: brightness(1.1);
      }
      .rk-btn-primary:disabled {
        opacity: 0.6;
        cursor: not-allowed;
        filter: none;
      }
      .rk-btn-secondary {
        width: 100%;
        height: 30px;
        background: #202020;
        color: #888888;
        font-weight: 600;
        font-size: 10px;
        border-radius: 6px;
        border: 1px solid #333333;
        cursor: pointer;
        transition: all 0.15s ease;
        text-align: center;
        text-decoration: none;
        display: flex;
        align-items: center;
        justify-content: center;
        box-sizing: border-box;
        margin-top: 8px;
      }
      .rk-btn-secondary:hover {
        background: #2a2a2a;
        color: #ffffff;
        border-color: #444444;
      }
      .rk-info-grid {
        display: flex;
        flex-direction: column;
        gap: 8px;
        margin: 16px 0;
        background: rgba(0, 0, 0, 0.25);
        border: 1px solid #333333;
        border-radius: 6px;
        padding: 12px;
      }
      .rk-info-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 4px 0;
        border-bottom: 1px dashed rgba(255, 255, 255, 0.08);
      }
      .rk-info-row:last-child {
        border-bottom: none;
      }
      .rk-info-label {
        font-size: 10px !important;
        font-weight: 600 !important;
        color: #888888 !important;
        text-transform: uppercase !important;
        letter-spacing: 0.5px !important;
        margin: 0 !important;
        line-height: 1.4 !important;
      }
      .rk-info-val {
        font-size: 11px !important;
        font-weight: 700 !important;
        color: #ffffff !important;
      }
      .rk-key-val {
        color: #f57f00 !important;
        font-family: monospace !important;
        letter-spacing: 1px !important;
      }
      .rk-timer-val {
        color: #4ade80 !important;
        font-family: monospace !important;
      }
        font-size: 13px;
        font-weight: 600;
        padding: 12px 14px;
        border-radius: 10px;
        margin-bottom: 16px;
        text-align: center;
      }
      .rk-success-box {
        background: #081524;
        border: 1px solid #1d4ed8;
        border-radius: 14px;
        padding: 20px;
        text-align: center;
        margin-bottom: 20px;
      }
      .rk-success-icon {
        width: 48px;
        height: 48px;
        background: rgba(34, 197, 94, 0.15);
        border: 1px solid rgba(34, 197, 94, 0.4);
        color: #4ade80;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 22px;
        margin: 0 auto 12px auto;
      }
      .rk-info-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 10px;
        margin-top: 14px;
        text-align: left;
        font-size: 12px;
        background: #030712;
        padding: 14px;
        border-radius: 10px;
        border: 1px solid #1f2937;
      }
      .rk-info-item label {
        color: #64748b;
        display: block;
        font-size: 10px;
        text-transform: uppercase;
        font-weight: 700;
        letter-spacing: 0.5px;
      }
      .rk-info-item span {
        color: #f3f4f6;
        font-weight: 700;
      }
      .rk-footer-note {
        text-align: center;
        font-size: 11px;
        color: #64748b;
        margin-top: 16px;
      }
    `;
    document.head.appendChild(style);
  }
  var Bid032License = {
    config: {
      storeUrl: DEFAULT_STORE_URL,
      onSuccess: null
    },
    lockUI: function () {
      if (typeof document !== 'undefined' && document.body) {
        document.body.classList.add('rk-locked');
        var children = document.body.children;
        for (var i = 0; i < children.length; i++) {
          var child = children[i];
          if (child.id !== 'rk-modal-overlay_0x3b1c(0x14)SCRIPT_0x3b1c(0x14)STYLE') {
            if (!child.hasAttribute('data-rk-hidden')) {
              child.setAttribute('data-rk-hidden_0x3b1c(0x15)block');
            }
            child.style.display = 'none';
          }
        }
      }
    },
    unlockUI: function () {
      if (typeof document !== 'undefined' && document.body) {
        document.body.classList.remove('rk-locked');
        var children = document.body.children;
        for (var i = 0; i < children.length; i++) {
          var child = children[i];
          if (child.id !== 'rk-modal-overlay_0x3b1c(0x16)data-rk-hidden')) {
            var origDisplay = child.getAttribute('data-rk-hidden');
            child.style.display = (origDisplay === 'block_0x3b1c(0x17)none_0x3b1c(0x18)' : origDisplay;
            child.removeAttribute('data-rk-hidden');
          }
        }
      }
      var overlay = document.getElementById('rk-modal-overlay');
      if (overlay) {
        overlay.remove();
      }
    },
    init: function (options) {
      options = options || {};
      injectStyles();
      var storedOverride = localStorage.getItem('rk_store_url');
      var rawStoreUrl = storedOverride || options.storeUrl || DEFAULT_STORE_URL;
      if (!rawStoreUrl || String(rawStoreUrl).toLowerCase().startsWith('file:')) {
        rawStoreUrl = DEFAULT_STORE_URL;
      }
      this.config.storeUrl = rawStoreUrl.replace(/\/$/, '');
      this.config.onSuccess = options.onSuccess || null;
      var cachedSession = localStorage.getItem('rk_global_session');
      var cachedKey = localStorage.getItem('rk_global_key');
      if (cachedSession && cachedKey) {
        this.validateSession(cachedSession, cachedKey);
      } else {
        this.renderActivationUI();
      }
      this.startBackgroundMonitor();
    },
    startBackgroundMonitor: function () {
      var self = this;
      if (self._bgMonitorInterval) {
        clearInterval(self._bgMonitorInterval);
      }
      var lastHeartbeatTime = 0;
      function checkExpiration() {
        var cachedSession = localStorage.getItem('rk_global_session');
        var cachedKey = localStorage.getItem('rk_global_key');
        var localExpiresMsStr = localStorage.getItem('rk_global_expires_ms');
        var expiresAtISO = localStorage.getItem('rk_global_expires_at');
        if (!cachedSession || !cachedKey) return;
        var nowMs = Date.now();
        var expiresMs = localExpiresMsStr ? parseInt(localExpiresMsStr, 10) : 0;
        if ((!expiresMs || isNaN(expiresMs)) && expiresAtISO) {
          var d = new Date(expiresAtISO);
          expiresMs = d.getTime();
          if (isNaN(expiresMs)) {
            expiresMs = new Date(String(expiresAtISO).replace(' ', 'T')).getTime();
          }
        }
        if (expiresMs && !isNaN(expiresMs) && nowMs >= expiresMs) {
          console.warn('[Bid032 License] License expired locally based on device clock!');
          localStorage.removeItem('rk_global_session');
          localStorage.removeItem('rk_global_key');
          localStorage.removeItem('rk_global_expires_at');
          localStorage.removeItem('rk_global_expires_ms');
          if (self._countdownInterval) {
            clearInterval(self._countdownInterval);
            self._countdownInterval = null;
          }
          self.renderActivationUI('Your license key has expired. Please enter a valid license key to continue.');
          return;
        }
        if (nowMs - lastHeartbeatTime >= 8000) {
          lastHeartbeatTime = nowMs;
          self.validateSession(cachedSession, cachedKey, true);
        }
      }
      checkExpiration();
      self._bgMonitorInterval = setInterval(checkExpiration, 1000);
    },
    validateSession: function (sessionId, licenseKey, isSilent) {
      var self = this;
      var deviceId = generateDeviceFingerprint();
      var url = this.config.storeUrl + '/api/v1/license/validate';
      sendPostRequest(url, {
        session_id: sessionId,
        license_key: licenseKey,
        device_id: deviceId
      }, function (err, data) {
        if (!err && data && data.valid) {
          var localMs = computeLocalExpiresMs(data);
          if (localMs !== null) {
            localStorage.setItem('rk_global_expires_ms', String(localMs));
            if (data.expires_at) localStorage.setItem('rk_global_expires_at', data.expires_at);
          }
          if (!isSilent) {
            self.unlockUI();
            if (typeof self.config.onSuccess === 'function') {
              self.config.onSuccess(data);
            }
          }
        } else if (err && (!data || !data.error)) {
          if (!isSilent) {
            self.unlockUI();
            if (typeof self.config.onSuccess === 'function') {
              self.config.onSuccess({ valid: true, offline: true });
            }
          }
        } else {
          console.warn('[Bid032 License] Server marked license as expired/invalid:', data);
          localStorage.removeItem('rk_global_session');
          localStorage.removeItem('rk_global_key');
          localStorage.removeItem('rk_global_expires_at');
          localStorage.removeItem('rk_global_expires_ms');
          if (self._countdownInterval) {
            clearInterval(self._countdownInterval);
            self._countdownInterval = null;
          }
          self.renderActivationUI((data && data.error) || 'Your license key has expired. Please enter a valid license key to continue.');
        }
      });
    },
    showLicenseDetails: function (sessionId, licenseKey) {
      var self = this;
      var cachedSession = sessionId || localStorage.getItem('rk_global_session');
      var cachedKey = licenseKey || localStorage.getItem('rk_global_key');
      if (!cachedSession || !cachedKey || cachedSession === 'null_0x3b1c(0x19)undefined') {
        self.renderActivationUI();
        return;
      }
      var deviceId = generateDeviceFingerprint();
      var url = this.config.storeUrl + '/api/v1/license/validate';
      sendPostRequest(url, {
        session_id: cachedSession,
        license_key: cachedKey,
        device_id: deviceId
      }, function (err, data) {
        if (!err && data && data.valid) {
          var localMs = computeLocalExpiresMs(data);
          if (localMs !== null) {
            localStorage.setItem('rk_global_expires_ms', String(localMs));
            if (data.expires_at) localStorage.setItem('rk_global_expires_at', data.expires_at);
          }
          self.renderSuccessUI(data, cachedKey);
        } else if (err && (!data || !data.error)) {
          self.renderSuccessUI({ valid: true, product_title: 'Gridora_0x3b1c(0x1a)Active License (Offline)' }, cachedKey);
        } else {
          localStorage.removeItem('rk_global_session');
          localStorage.removeItem('rk_global_key');
          localStorage.removeItem('rk_global_expires_at');
          localStorage.removeItem('rk_global_expires_ms');
          self.renderActivationUI();
        }
      });
    },
    activateKey: function (rawKey) {
      var self = this;
      var cleanKey = (rawKey || '_0x3b1c(0x1b)').toUpperCase();
      if (!cleanKey || cleanKey.length < 10) {
        self.showError('Please enter a valid license key (e.g. XXXX-XXXX-XXXX-XXXX).');
        return;
      }
      var btn = document.getElementById('rk-activate-btn');
      if (btn) {
        btn.disabled = true;
        btn.innerHTML = 'Verifying License...';
      }
      var deviceId = generateDeviceFingerprint();
      var installId = getInstallationId();
      var url = this.config.storeUrl + '/api/v1/license/activate';
      sendPostRequest(url, {
        license_key: cleanKey,
        device_id: deviceId,
        installation_id: installId,
        device_name: 'Workstation (_0x3b1c(0x1c)Desktop_0x3b1c(0xc))',
        platform: navigator.userAgent || 'Web'
      }, function (err, data) {
        if (btn) {
          btn.disabled = false;
          btn.innerHTML = 'Activate License';
        }
        if (!err && data) {
          if (data.valid) {
            localStorage.setItem('rk_global_session', data.session_id);
            localStorage.setItem('rk_global_key', cleanKey);
            var localMs = computeLocalExpiresMs(data);
            if (localMs !== null) {
              localStorage.setItem('rk_global_expires_ms', String(localMs));
              if (data.expires_at) localStorage.setItem('rk_global_expires_at', data.expires_at);
            }
            self.renderSuccessUI(data, cleanKey);
          } else {
            self.showError(data.error || 'Invalid license key.');
          }
        } else {
          self.showError((err && err.message) || 'Unable to connect to license server. Please check internet connection.');
        }
      });
    },
    renderActivationUI: function (errorMessage) {
      var self = this;
      self.lockUI();
      var overlay = document.getElementById('rk-modal-overlay');
      if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'rk-modal-overlay';
        overlay.className = 'rk-modal-overlay';
        document.body.appendChild(overlay);
      }
      overlay.style.cssText = 'position:fixed !important; top:0 !important; left:0 !important; right:0 !important; bottom:0 !important; width:100% !important; height:100% !important; background:#141414 !important; display:flex !important; align-items:center !important; justify-content:center !important; z-index:99999999 !important; padding:16px !important; box-sizing:border-box !important;';
      var buyUrl = (this.config.storeUrl || DEFAULT_STORE_URL) + '/store';
      overlay.innerHTML = `
        <div class="rk-card">
          <div class="rk-header">
            <span class="rk-badge">Bid032 LICENSE SYSTEM</span>
            <h2 class="rk-title">Activate Software License</h2>
            <p class="rk-subtitle">Enter your official license key below to unlock full tool functionality.</p>
          </div>
          <div id="rk-error-box" class="rk-error" style="${errorMessage ? '_0x3b1c(0x1d)display:none;'}">
            ${errorMessage || ''}
          </div>
          <div class="rk-input-group">
            <label class="rk-label">License Key</label>
            <input type="text" id="rk-key-input" class="rk-input" placeholder="XXXX-XXXX-XXXX-XXXX" maxlength="30" autocomplete="off" spellcheck="false">
          </div>
          <button id="rk-activate-btn" class="rk-btn-primary" type="button">
            Activate License
          </button>
          <button id="rk-buy-btn" class="rk-btn-secondary" type="button">
            Don't have a license? Buy or Claim Free Trial
          </button>
          <div class=_0x3b1c(0x1e)>
            Secured by Abdallah Store License Platform
          </div>
        </div>
      `;
      injectStyles();
      var buyBtn = document.getElementById(_0x3b1c(0x1f));
      if (buyBtn) {
        buyBtn.addEventListener(_0x3b1c(0x20), function (e) {
          if (e && e.preventDefault) e.preventDefault();
          if (e && e.stopPropagation) e.stopPropagation();
          openExternalUrl(buyUrl);
        });
      }
      var input = document.getElementById(_0x3b1c(0x21));
      if (input) {
        input.addEventListener(_0x3b1c(0x22), function (e) {
          var val = e.target.value.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
          var formatted = '';
          for (var i = 0; i < val.length; i++) {
            if (i > 0 && i % 4 === 0) formatted += '-';
            formatted += val[i];
          }
          e.target.value = formatted.substring(0, 23);
        });
        input.addEventListener(_0x3b1c(0x23), function (e) {
          if (e.key === _0x3b1c(0x24)) {
            self.activateKey(input.value);
          }
        });
      }
      var btn = document.getElementById(_0x3b1c(0x25));
      if (btn) {
        btn.addEventListener(_0x3b1c(0x20), function () {
          self.activateKey(input.value);
        });
      }
    },
    renderSuccessUI: function (data, licenseKey) {
      var self = this;
      self.lockUI();
      if (self._countdownInterval) {
        clearInterval(self._countdownInterval);
        self._countdownInterval = null;
      }
      var overlay = document.getElementById(_0x3b1c(0x26));
      if (!overlay) {
        overlay = document.createElement(_0x3b1c(0x27));
        overlay.id = _0x3b1c(0x26);
        overlay.className = _0x3b1c(0x26);
        document.body.appendChild(overlay);
      }
      overlay.style.cssText = _0x3b1c(0x28);
      var localExpiresMs = computeLocalExpiresMs(data);
      if (localExpiresMs) {
        localStorage.setItem(_0x3b1c(0x29), String(localExpiresMs));
      } else {
        var storedMs = localStorage.getItem(_0x3b1c(0x29));
        if (storedMs) localExpiresMs = parseInt(storedMs, 10);
      }
      var expiresDateFormatted = _0x3b1c(0x2a);
      if (localExpiresMs && !isNaN(localExpiresMs) && localExpiresMs > 0) {
        expiresDateFormatted = formatLocalDateTimeSmart(localExpiresMs);
      }
      var toolTitle = data.product_title || _0x3b1c(0x2b);
      var planName = data.plan_name || _0x3b1c(0x2c);
      var keyLast4 = licenseKey ? licenseKey.replace(/[^A-Za-z0-9]/g, '').slice(-4) : _0x3b1c(0x2d);
      overlay.innerHTML = `
        <div class=_0x3b1c(0x2e)>
          <div class=_0x3b1c(0x2f)>
            <span class=_0x3b1c(0x30) style=_0x3b1c(0x31)>
              ✓ LICENSE ACTIVE
            </span>
            <h2 class=_0x3b1c(0x32)>Gridora License Details</h2>
            <p class=_0x3b1c(0x33)>Your software license is active & verified.</p>
          </div>
          <div class=_0x3b1c(0x34)>
            <div class=_0x3b1c(0x35)>
              <span class=_0x3b1c(0x36)>Product Name</span>
              <span class=_0x3b1c(0x37) style=_0x3b1c(0x38)>${toolTitle}</span>
            </div>
            <div class=_0x3b1c(0x35)>
              <span class=_0x3b1c(0x36)>Active Plan</span>
              <span class=_0x3b1c(0x37)>${planName}</span>
            </div>
            <div class=_0x3b1c(0x35)>
              <span class=_0x3b1c(0x36)>License Key</span>
              <span class=_0x3b1c(0x39)>••••-••••-••••-${keyLast4}</span>
            </div>
            <div class=_0x3b1c(0x35)>
              <span class=_0x3b1c(0x36)>Expiration Date</span>
              <span class=_0x3b1c(0x37)>${expiresDateFormatted}</span>
            </div>
            <div class=_0x3b1c(0x35)>
              <span class=_0x3b1c(0x36)>Time Remaining</span>
              <span id=_0x3b1c(0x3a) class=_0x3b1c(0x3b)>Calculating...</span>
            </div>
          </div>
          <button id=_0x3b1c(0x3c) class=_0x3b1c(0x3d) type=_0x3b1c(0x3e) style=_0x3b1c(0x3f)>
            Close Details
          </button>
          <button id=_0x3b1c(0x40) class=_0x3b1c(0x41) type=_0x3b1c(0x3e)>
            Deactivate / Change Key
          </button>
        </div>
      `;
      function updateTimer() {
        var timerEl = document.getElementById(_0x3b1c(0x3a));
        if (!timerEl) {
          if (self._countdownInterval) {
            clearInterval(self._countdownInterval);
            self._countdownInterval = null;
          }
          return;
        }
        if (!localExpiresMs || isNaN(localExpiresMs) || localExpiresMs <= 0) {
          timerEl.innerText = _0x3b1c(0x42);
          timerEl.style.color = _0x3b1c(0x43);
          return;
        }
        var nowMs = Date.now();
        var diff = localExpiresMs - nowMs;
        if (diff <= 0) {
          if (self._countdownInterval) {
            clearInterval(self._countdownInterval);
            self._countdownInterval = null;
          }
          localStorage.removeItem(_0x3b1c(0x44));
          localStorage.removeItem(_0x3b1c(0x45));
          localStorage.removeItem(_0x3b1c(0x46));
          localStorage.removeItem(_0x3b1c(0x29));
          self.renderActivationUI(_0x3b1c(0x47));
          return;
        }
        var totalSeconds = Math.floor(diff / 1000);
        var days = Math.floor(totalSeconds / 86400);
        var hours = Math.floor((totalSeconds % 86400) / 3600);
        var minutes = Math.floor((totalSeconds % 3600) / 60);
        var seconds = totalSeconds % 60;
        var parts = [];
        if (days > 0) parts.push(days + 'd');
        if (hours > 0 || days > 0) parts.push(hours + 'h');
        parts.push(minutes + 'm');
        parts.push(seconds + 's');
        timerEl.innerText = parts.join(' ');
      }
      updateTimer();
      self._countdownInterval = setInterval(updateTimer, 1000);
      document.getElementById(_0x3b1c(0x3c)).addEventListener(_0x3b1c(0x20), function () {
        if (self._countdownInterval) {
          clearInterval(self._countdownInterval);
          self._countdownInterval = null;
        }
        self.unlockUI();
        if (typeof self.config.onSuccess === _0x3b1c(0x6)) {
          self.config.onSuccess(data);
        }
      });
      document.getElementById(_0x3b1c(0x40)).addEventListener(_0x3b1c(0x20), function () {
        if (self._countdownInterval) {
          clearInterval(self._countdownInterval);
          self._countdownInterval = null;
        }
        localStorage.removeItem(_0x3b1c(0x44));
        localStorage.removeItem(_0x3b1c(0x45));
        self.renderActivationUI();
      });
    },
    showError: function (msg) {
      var box = document.getElementById(_0x3b1c(0x48));
      if (box) {
        box.innerText = msg;
        box.style.display = _0x3b1c(0x49);
      }
    },
    openExternalUrl: openExternalUrl
  };
  global.Bid032License = Bid032License;
  global.RapidKeyzLicense = Bid032License;
  function autoInit() {
    if (global.Bid032License && typeof global.Bid032License.init === _0x3b1c(0x6)) {
      global.Bid032License.init({
        storeUrl: DEFAULT_STORE_URL,
        onSuccess: function (data) {
          console.log(_0x3b1c(0x4a), data);
        }
      });
    }
  }
  if (typeof document !== _0x3b1c(0x1)) {
    if (document.readyState === _0x3b1c(0x4b) || document.readyState === _0x3b1c(0x4c)) {
      autoInit();
    } else {
      document.addEventListener(_0x3b1c(0x4d), autoInit);
    }
    document.addEventListener(_0x3b1c(0x20), function (e) {
      var target = e.target;
      if (target && (target.id === _0x3b1c(0x4e) || (target.closest && target.closest(_0x3b1c(0x4f))))) {
        if (e && e.preventDefault) e.preventDefault();
        if (e && e.stopPropagation) e.stopPropagation();
        if (global.Bid032License && typeof global.Bid032License.showLicenseDetails === _0x3b1c(0x6)) {
          global.Bid032License.showLicenseDetails();
        }
      }
    });
  }
})(typeof window !== _0x3b1c(0x1) ? window : this);
})();