Thank you for purchasing Gridora.

Installation:
1. Open Adobe Creative Cloud Desktop.
2. Double-click the Gridora V2.ccx file.
3. Follow the installation steps.
4. Open Photoshop and launch Gridora from Plugins.

Support:
bid032.com