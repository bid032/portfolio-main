@echo off
setlocal

set "DEST=%APPDATA%\Adobe\CEP\extensions\com.mohamedhabib.arabicdirection"

if exist "%DEST%" (
    rmdir /S /Q "%DEST%"
    echo Arabic Direction panel removed.
) else (
    echo Arabic Direction panel is not installed for this Windows user.
)

echo Restart Illustrator to finish.
pause

