@echo off
setlocal
chcp 65001 >nul

set "SOURCE=%~dp0Arabic_Direction_Panel"
set "DEST=%APPDATA%\Adobe\CEP\extensions\com.mohamedhabib.arabicdirection"

if not exist "%SOURCE%\CSXS\manifest.xml" (
    echo Installation files were not found.
    echo Extract the complete ZIP file first, then run this installer again.
    pause
    exit /b 1
)

if not exist "%APPDATA%\Adobe\CEP\extensions" (
    mkdir "%APPDATA%\Adobe\CEP\extensions"
)

if not exist "%DEST%" mkdir "%DEST%"
xcopy "%SOURCE%\*" "%DEST%\" /E /I /Y >nul

for %%V in (9 10 11 12 13) do (
    reg add "HKCU\Software\Adobe\CSXS.%%V" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
)

echo.
echo Arabic Direction panel v1.1 installed successfully.
echo Restart Illustrator, then open:
echo Window ^> Extensions ^(Legacy^) ^> Arabic Direction
echo or Window ^> Extensions ^> Arabic Direction
echo.
pause
exit /b 0
