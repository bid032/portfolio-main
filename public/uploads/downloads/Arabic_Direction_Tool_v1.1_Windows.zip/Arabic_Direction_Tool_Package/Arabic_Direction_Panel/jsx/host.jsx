#target illustrator

var ArabicDirectionPanel = ArabicDirectionPanel || {};

ArabicDirectionPanel.applyDirection = function (directionName, scopeName) {
    try {
        if (app.documents.length === 0) return "NO_DOCUMENT";

        var doc = app.activeDocument;
        var ranges = [];

        if (scopeName === "document") {
            ArabicDirectionPanel.collectAllRanges(doc, ranges);
            if (ranges.length === 0) return "NO_TEXT";
        } else {
            ArabicDirectionPanel.collectSelectedRanges(doc.selection, ranges);
            if (ranges.length === 0) return "NO_SELECTION";
        }

        var destination = directionName === "rtl"
            ? ParagraphDirectionType.RIGHT_TO_LEFT_DIRECTION
            : ParagraphDirectionType.LEFT_TO_RIGHT_DIRECTION;

        var changed = 0;
        var skipped = 0;

        for (var i = 0; i < ranges.length; i++) {
            try {
                ArabicDirectionPanel.applyDirectionToRange(ranges[i], destination);
                changed++;
            } catch (itemError) {
                skipped++;
            }
        }

        app.redraw();
        return "OK|" + changed + "|" + skipped;
    } catch (error) {
        return "ERROR|" + error.message;
    }
};

ArabicDirectionPanel.getDirectionState = function (scopeName) {
    try {
        if (app.documents.length === 0) return "none";

        var doc = app.activeDocument;
        var ranges = [];

        if (scopeName === "document") {
            ArabicDirectionPanel.collectAllRanges(doc, ranges);
        } else {
            ArabicDirectionPanel.collectSelectedRanges(doc.selection, ranges);
        }

        if (ranges.length === 0) return "none";

        var seenRTL = false;
        var seenLTR = false;

        for (var i = 0; i < ranges.length; i++) {
            var paragraphs = ranges[i].paragraphs;

            if (paragraphs.length === 0) {
                ArabicDirectionPanel.trackDirection(ranges[i], function (state) {
                    if (state === "rtl") seenRTL = true;
                    if (state === "ltr") seenLTR = true;
                });
            } else {
                for (var p = 0; p < paragraphs.length; p++) {
                    ArabicDirectionPanel.trackDirection(paragraphs[p], function (state) {
                        if (state === "rtl") seenRTL = true;
                        if (state === "ltr") seenLTR = true;
                    });
                }
            }

            if (seenRTL && seenLTR) return "mixed";
        }

        if (seenRTL) return "rtl";
        if (seenLTR) return "ltr";
        return "none";
    } catch (error) {
        return "none";
    }
};

ArabicDirectionPanel.trackDirection = function (range, callback) {
    try {
        var current = range.paragraphDirection;
        if (current === ParagraphDirectionType.RIGHT_TO_LEFT_DIRECTION) {
            callback("rtl");
        } else if (current === ParagraphDirectionType.LEFT_TO_RIGHT_DIRECTION) {
            callback("ltr");
        }
    } catch (ignored) {}
};

ArabicDirectionPanel.applyDirectionToRange = function (range, destination) {
    var paragraphs = range.paragraphs;

    if (paragraphs.length === 0) {
        ArabicDirectionPanel.setParagraphDirection(range, destination);
    } else {
        for (var p = 0; p < paragraphs.length; p++) {
            ArabicDirectionPanel.setParagraphDirection(paragraphs[p], destination);
        }
    }

    try {
        range.dirOverride = DirOverrideType.DEFAULT_DIRECTION;
    } catch (ignored) {}
};

ArabicDirectionPanel.setParagraphDirection = function (range, destination) {
    var appliedStyle;
    var originalStyleDirection;

    try {
        appliedStyle = range.paragraphStyles[0];
        originalStyleDirection = appliedStyle.paragraphDirection;

        if (originalStyleDirection === destination) {
            var opposite = destination === ParagraphDirectionType.RIGHT_TO_LEFT_DIRECTION
                ? ParagraphDirectionType.LEFT_TO_RIGHT_DIRECTION
                : ParagraphDirectionType.RIGHT_TO_LEFT_DIRECTION;

            appliedStyle.paragraphDirection = opposite;
            range.paragraphDirection = destination;
            appliedStyle.paragraphDirection = originalStyleDirection;
        } else {
            range.paragraphDirection = destination;
        }
    } catch (primaryError) {
        try {
            if (appliedStyle && originalStyleDirection !== undefined) {
                appliedStyle.paragraphDirection = originalStyleDirection;
            }
        } catch (restoreError) {}

        range.paragraphDirection = destination;
    }
};

ArabicDirectionPanel.collectAllRanges = function (documentObject, output) {
    for (var i = 0; i < documentObject.textFrames.length; i++) {
        ArabicDirectionPanel.addUnique(documentObject.textFrames[i].textRange, output);
    }
};

ArabicDirectionPanel.collectSelectedRanges = function (selectionObject, output) {
    if (!selectionObject) return;

    if (selectionObject.typename === "TextRange") {
        ArabicDirectionPanel.addUnique(selectionObject, output);
        return;
    }

    if (selectionObject.length === undefined) {
        ArabicDirectionPanel.collectFromItem(selectionObject, output);
        return;
    }

    for (var i = 0; i < selectionObject.length; i++) {
        ArabicDirectionPanel.collectFromItem(selectionObject[i], output);
    }
};

ArabicDirectionPanel.collectFromItem = function (item, output) {
    if (!item) return;

    if (item.typename === "TextRange") {
        ArabicDirectionPanel.addUnique(item, output);
    } else if (item.typename === "TextFrame") {
        ArabicDirectionPanel.addUnique(item.textRange, output);
    } else if (item.typename === "GroupItem") {
        for (var i = 0; i < item.pageItems.length; i++) {
            ArabicDirectionPanel.collectFromItem(item.pageItems[i], output);
        }
    }
};

ArabicDirectionPanel.addUnique = function (range, output) {
    for (var i = 0; i < output.length; i++) {
        if (output[i] === range) return;
    }
    output.push(range);
};

