(function () {
    "use strict";

    var adobeCep = window.__adobe_cep__;
    var rtlButton = document.getElementById("rtlButton");
    var ltrButton = document.getElementById("ltrButton");
    var refreshButton = document.getElementById("refreshButton");
    var scopeSelect = document.getElementById("scopeSelect");
    var statusElement = document.getElementById("status");
    var externalLinks = document.querySelectorAll("[data-external-url]");
    var busy = false;

    function setStatus(message, kind) {
        statusElement.textContent = message;
        statusElement.className = "status" + (kind ? " " + kind : "");
    }

    function setBusy(value) {
        busy = value;
        rtlButton.classList.toggle("busy", value);
        ltrButton.classList.toggle("busy", value);
    }

    function setActiveDirection(direction) {
        rtlButton.classList.toggle("active", direction === "rtl");
        ltrButton.classList.toggle("active", direction === "ltr");
    }

    function evaluate(script, callback) {
        if (!adobeCep || typeof adobeCep.evalScript !== "function") {
            setStatus("CEP host connection is unavailable.", "error");
            return;
        }
        adobeCep.evalScript(script, callback);
    }

    function openExternalLink(event) {
        event.preventDefault();

        var url = event.currentTarget.getAttribute("data-external-url");
        if (!url || url.indexOf("https://") !== 0) {
            setStatus("This link is unavailable.", "error");
            return;
        }

        try {
            if (
                window.cep &&
                window.cep.util &&
                typeof window.cep.util.openURLInDefaultBrowser === "function"
            ) {
                var result = window.cep.util.openURLInDefaultBrowser(url);
                if (result === 0 || typeof result === "undefined") return;
            }
        } catch (ignored) {}

        try {
            var openedWindow = window.open(url, "_blank");
            if (openedWindow) return;
        } catch (ignoredWindowError) {}

        setStatus("Could not open the link in your browser.", "error");
    }

    function applyDirection(direction) {
        if (busy) return;

        setBusy(true);
        setStatus("Applying " + direction.toUpperCase() + "...", "");

        var scope = scopeSelect.value;
        var script = 'ArabicDirectionPanel.applyDirection("' + direction + '","' + scope + '")';

        evaluate(script, function (result) {
            setBusy(false);
            handleApplyResult(result, direction);
        });
    }

    function handleApplyResult(result, direction) {
        var parts = String(result || "").split("|");
        var code = parts[0];

        if (code === "OK") {
            var changed = parts[1] || "0";
            var skipped = parts[2] || "0";
            setActiveDirection(direction);
            setStatus(
                direction.toUpperCase() + " applied to " + changed +
                (skipped !== "0" ? "; skipped " + skipped + "." : "."),
                "success"
            );
        } else if (code === "NO_DOCUMENT") {
            setActiveDirection("none");
            setStatus("Open an Illustrator document first.", "error");
        } else if (code === "NO_SELECTION") {
            setActiveDirection("none");
            setStatus("Select a text object or choose Entire document.", "error");
        } else if (code === "NO_TEXT") {
            setActiveDirection("none");
            setStatus("No text objects were found.", "error");
        } else {
            setActiveDirection("none");
            setStatus(parts.slice(1).join("|") || "Illustrator could not apply the direction.", "error");
        }
    }

    function refreshState() {
        if (busy) return;

        var scope = scopeSelect.value;
        evaluate('ArabicDirectionPanel.getDirectionState("' + scope + '")', function (result) {
            var state = String(result || "none");
            if (state === "rtl" || state === "ltr") {
                setActiveDirection(state);
                setStatus(state.toUpperCase() + " paragraph direction.", "");
            } else if (state === "mixed") {
                setActiveDirection("none");
                setStatus("Mixed paragraph directions.", "");
            } else {
                setActiveDirection("none");
                if (scope === "selection") {
                    setStatus("Select text, then choose a direction.", "");
                } else {
                    setStatus("No text direction to display.", "");
                }
            }
        });
    }

    rtlButton.addEventListener("click", function () {
        applyDirection("rtl");
    });

    ltrButton.addEventListener("click", function () {
        applyDirection("ltr");
    });

    refreshButton.addEventListener("click", refreshState);
    scopeSelect.addEventListener("change", refreshState);
    window.addEventListener("focus", refreshState);

    for (var i = 0; i < externalLinks.length; i++) {
        externalLinks[i].addEventListener("click", openExternalLink);
    }

    setTimeout(refreshState, 250);
})();
