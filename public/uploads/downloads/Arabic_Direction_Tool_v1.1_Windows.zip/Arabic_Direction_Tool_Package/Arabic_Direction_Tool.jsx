#target illustrator

/*
  Arabic Direction Tool for Adobe Illustrator
  Applies RTL or LTR paragraph direction without changing visual formatting.
*/

(function () {
    if (app.documents.length === 0) {
        alert("Open an Illustrator document first.");
        return;
    }

    var doc = app.activeDocument;
    var selectedRanges = [];
    var allRanges = [];

    collectSelectedRanges(doc.selection, selectedRanges);
    collectAllRanges(doc, allRanges);

    if (allRanges.length === 0) {
        alert("No text objects were found in this document.");
        return;
    }

    var dialog = new Window("dialog", "Arabic Direction Tool");
    dialog.orientation = "column";
    dialog.alignChildren = "fill";

    var message = dialog.add(
        "statictext",
        undefined,
        "Change paragraph direction only. Text formatting stays untouched.",
        { multiline: true }
    );
    message.preferredSize.width = 420;

    var scopePanel = dialog.add("panel", undefined, "Apply to");
    scopePanel.orientation = "column";
    scopePanel.alignChildren = "left";

    var selectionRadio = scopePanel.add(
        "radiobutton",
        undefined,
        "Selected text (" + selectedRanges.length + ")"
    );
    var documentRadio = scopePanel.add(
        "radiobutton",
        undefined,
        "Entire document (" + allRanges.length + " text object(s))"
    );

    selectionRadio.enabled = selectedRanges.length > 0;
    if (selectedRanges.length > 0) {
        selectionRadio.value = true;
    } else {
        documentRadio.value = true;
    }

    var directionPanel = dialog.add("panel", undefined, "Paragraph direction");
    directionPanel.orientation = "row";
    directionPanel.alignChildren = "fill";

    var rtlButton = directionPanel.add("button", undefined, "\u25C0   RTL");
    var ltrButton = directionPanel.add("button", undefined, "LTR   \u25B6");
    rtlButton.preferredSize = [150, 42];
    ltrButton.preferredSize = [150, 42];

    var cancelButton = dialog.add("button", undefined, "Cancel", { name: "cancel" });
    cancelButton.alignment = "right";

    var chosenDirection = null;
    rtlButton.onClick = function () {
        chosenDirection = "rtl";
        dialog.close(1);
    };
    ltrButton.onClick = function () {
        chosenDirection = "ltr";
        dialog.close(1);
    };

    if (dialog.show() !== 1 || chosenDirection === null) {
        return;
    }

    var ranges = selectionRadio.value ? selectedRanges : allRanges;
    var destinationDirection = chosenDirection === "rtl"
        ? ParagraphDirectionType.RIGHT_TO_LEFT_DIRECTION
        : ParagraphDirectionType.LEFT_TO_RIGHT_DIRECTION;

    var changed = 0;
    var skipped = 0;

    for (var i = 0; i < ranges.length; i++) {
        try {
            applyDirectionToRange(ranges[i], destinationDirection);
            changed++;
        } catch (error) {
            skipped++;
        }
    }

    app.redraw();

    var result = chosenDirection.toUpperCase() + " applied to " + changed + " text selection(s).";
    if (skipped > 0) {
        result += "\nSkipped " + skipped + " locked or unsupported selection(s).";
    }
    alert(result);

    function applyDirectionToRange(range, destination) {
        var paragraphs = range.paragraphs;

        if (paragraphs.length === 0) {
            setParagraphDirection(range, destination);
        } else {
            for (var p = 0; p < paragraphs.length; p++) {
                setParagraphDirection(paragraphs[p], destination);
            }
        }

        try {
            range.dirOverride = DirOverrideType.DEFAULT_DIRECTION;
        } catch (ignored) {}
    }

    function setParagraphDirection(range, destination) {
        var appliedStyle;
        var originalStyleDirection;

        try {
            appliedStyle = range.paragraphStyles[0];
            originalStyleDirection = appliedStyle.paragraphDirection;

            if (originalStyleDirection === destination) {
                var opposite = destination === ParagraphDirectionType.RIGHT_TO_LEFT_DIRECTION
                    ? ParagraphDirectionType.LEFT_TO_RIGHT_DIRECTION
                    : ParagraphDirectionType.RIGHT_TO_LEFT_DIRECTION;

                appliedStyle.paragraphDirection = opposite;
                range.paragraphDirection = destination;
                appliedStyle.paragraphDirection = originalStyleDirection;
            } else {
                range.paragraphDirection = destination;
            }
        } catch (primaryError) {
            try {
                if (appliedStyle && originalStyleDirection !== undefined) {
                    appliedStyle.paragraphDirection = originalStyleDirection;
                }
            } catch (restoreError) {}

            range.paragraphDirection = destination;
        }
    }

    function collectAllRanges(documentObject, output) {
        for (var i = 0; i < documentObject.textFrames.length; i++) {
            addUnique(documentObject.textFrames[i].textRange, output);
        }
    }

    function collectSelectedRanges(selectionObject, output) {
        if (!selectionObject) return;

        if (selectionObject.typename === "TextRange") {
            addUnique(selectionObject, output);
            return;
        }

        if (selectionObject.length === undefined) {
            collectFromItem(selectionObject, output);
            return;
        }

        for (var i = 0; i < selectionObject.length; i++) {
            collectFromItem(selectionObject[i], output);
        }
    }

    function collectFromItem(item, output) {
        if (!item) return;

        if (item.typename === "TextRange") {
            addUnique(item, output);
        } else if (item.typename === "TextFrame") {
            addUnique(item.textRange, output);
        } else if (item.typename === "GroupItem") {
            for (var i = 0; i < item.pageItems.length; i++) {
                collectFromItem(item.pageItems[i], output);
            }
        }
    }

    function addUnique(range, output) {
        for (var i = 0; i < output.length; i++) {
            if (output[i] === range) return;
        }
        output.push(range);
    }
})();

