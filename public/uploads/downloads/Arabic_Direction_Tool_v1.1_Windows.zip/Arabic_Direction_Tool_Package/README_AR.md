# Arabic Direction Tool لـ Adobe Illustrator

**الإصدار:** 1.1.0

الأداة بتضيف زرين لاتجاه الفقرة داخل Illustrator:

- **RTL**: اتجاه من اليمين إلى اليسار.
- **LTR**: اتجاه من اليسار إلى اليمين.

الأداة لا تغيّر الخط أو الحجم أو الوزن أو اللون أو الـTracking أو الـLeading أو المحاذاة، ولا تطبّق Character Styles أو Paragraph Styles.

واجهة الـPanel مبنية بألوان هوية Mohamed Habib: الأسود والأبيض مع درجات الأزرق `#061FA8` و`#1237FF` و`#3F68FF`.

## تثبيت الـPanel على Windows

1. اقفل Illustrator بالكامل.
2. فك ضغط الحزمة في فولدر عادي.
3. شغّل `Install_Windows.bat`.
4. افتح Illustrator من جديد.
5. افتح الأداة من أحد المسارين، حسب ما يظهر في نسختك:
   - `Window > Extensions > Arabic Direction`
   - `Window > Extensions (Legacy) > Arabic Direction`
6. اسحب الـPanel وثبّته بجانب Paragraph أو Character.

الـInstaller ينسخ الإضافة إلى مجلد إضافات المستخدم ويفعّل تشغيل إضافات CEP المحلية غير الموقعة لحساب Windows الحالي فقط. لا يغيّر ملفات Illustrator.

## الاستخدام

1. حدّد Text Box أو حدّد جزءًا من النص بأداة الكتابة.
2. اختار `Selection` من القائمة.
3. اضغط أيقونة `RTL` أو `LTR`.

لاستخدام الاتجاه على كل النصوص في الملف، اختار `Entire document` قبل الضغط على الاتجاه.

## النسخة العادية بدون Panel

لو الـPanel لم يظهر، استخدم `Arabic_Direction_Tool.jsx`:

1. افتح `File > Scripts > Other Script`.
2. اختار ملف `Arabic_Direction_Tool.jsx`.
3. اختار النطاق ثم اضغط RTL أو LTR.

ولتثبيت السكربت داخل قائمة Scripts، انسخه إلى مجلد Scripts داخل تثبيت Illustrator، ثم أعد تشغيل Illustrator. تشغيله من `Other Script` لا يحتاج تثبيتًا.

## إزالة الـPanel

اقفل Illustrator وشغّل `Uninstall_Windows.bat`.

## روابط المطوّر

- [Behance](https://www.behance.net/mohamedhabib)
- [LinkedIn](https://www.linkedin.com/in/mohamed-habib%E2%9C%AA/)
- [Instagram](https://www.instagram.com/mohamedhabib.designs)
- [YouTube](https://www.youtube.com/channel/UCG_STbkYZeQebhMkJCLsigA)
- [Website](https://habibvisuals.wuaze.com)

Copyright © Mohamed Habib 2026. All rights reserved.
