/*
  ================================================================================
  Outliner Pro Suite — Designed for bido (bid032.com)
  ================================================================================
  Compatible with Adobe Illustrator CS6 & CC (ExtendScript / JavaScript ES3)
  
  Features & Engine:
  1. Anti-Collision Vector Label Positioning Engine (Zero Text Overlaps).
  2. Clean Vector Typography (No Heavy Badges / Boxes).
  3. Global Sequential Anchor Indexing (1...N).
  4. Precise Osculating Curvature Circles & Radius Callouts ("R: xx.x px").
  5. Straight Edge Geometry Tangent Extensions & Bounding Box Guides.
  6. Technical CAD Dimensions (W / H px) & Presentation Background Cards.
  7. Designer Watermark Credit ("Designed by Bido | bid032.com").
  8. Auto Session Preference Memory & Non-Destructive Live Preview.
  ================================================================================
*/

#target illustrator

  (function () {
    if (app.documents.length === 0) {
      alert("Please open an Illustrator document before running Outliner Pro.");
      return;
    }

    var doc = app.activeDocument;
    var PREVIEW_LAYER_NAME = "_Outliner_Visuals";
    var SETTINGS_FILE_PATH = Folder.userData + "/OutlinerPro_UserSettings.txt";
    var hiddenOriginals = [];

    // --- Preset Definitions ---
    var PRESETS = {
      OUTLINER_PRO: { name: "Outliner Pro (Clean Grid)", useLayerColor: false, anchorRGB: [25, 25, 30], outlineRGB: [80, 80, 85] },
      LAYER_ACCENT: { name: "Layer Accent Color", useLayerColor: true, anchorRGB: [50, 50, 200], outlineRGB: [35, 31, 32] },
      CLASSIC_BLUE: { name: "Classic Illustrator Blue", useLayerColor: false, anchorRGB: [30, 120, 240], outlineRGB: [35, 31, 32] },
      NEON_CYAN: { name: "Neon Cyberpunk Cyan", useLayerColor: false, anchorRGB: [0, 240, 255], outlineRGB: [20, 20, 35] },
      BLUEPRINT: { name: "CAD Blueprint White", useLayerColor: false, anchorRGB: [255, 255, 255], outlineRGB: [0, 80, 180] },
      MINIMAL_DARK: { name: "Minimalist Dark Gray", useLayerColor: false, anchorRGB: [40, 40, 40], outlineRGB: [180, 180, 180] },
      CUSTOM: { name: "Custom RGB Color...", useLayerColor: false, anchorRGB: [255, 100, 0], outlineRGB: [30, 30, 30] }
    };

    var RAINBOW_PALETTE = [
      [0, 180, 255],   // Cyan
      [255, 60, 120],  // Magenta
      [255, 200, 0],   // Gold
      [0, 230, 140],   // Emerald
      [160, 80, 255],  // Purple
      [255, 120, 0]    // Orange
    ];

    var savedSettings = loadUserSettings();

    showDialog();

    // ============================================================================
    // SCRIPT UI DIALOG WITH LIVE PREVIEW & ANTI-COLLISION ENGINE
    // ============================================================================
    function showDialog() {
      var win = new Window("dialog", "Outliner Pro v1.0 - By: Bido");
      win.orientation = "column";
      win.alignChildren = ["fill", "top"];
      win.spacing = 5;
      win.margins = 10;

      // --- Header ---
      var headerGroup = win.add("group");
      headerGroup.orientation = "row";
      headerGroup.alignChildren = ["fill", "center"];

      var chkLivePreview = headerGroup.add("checkbox", undefined, " Live Preview");
      chkLivePreview.value = true;
      chkLivePreview.graphics.foregroundColor = chkLivePreview.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [0, 0.45, 0.85, 1], 1);

      var lblStats = headerGroup.add("statictext", undefined, "Paths: 0  |  Anchors: 0  |  Handles: 0");
      lblStats.alignment = ["right", "center"];

      // --- 1. Scope Panel ---
      var scopePanel = win.add("panel", undefined, "Target Scope");
      scopePanel.orientation = "row";
      scopePanel.alignChildren = ["left", "center"];
      scopePanel.margins = 5;
      scopePanel.spacing = 12;

      var radSelected = scopePanel.add("radiobutton", undefined, "Selected Objects Only");
      var radEntireDoc = scopePanel.add("radiobutton", undefined, "Entire Document");
      if (doc.selection && doc.selection.length > 0) {
        radSelected.value = true;
      } else {
        radEntireDoc.value = true;
        radSelected.enabled = false;
      }

      var chkHideOriginal = scopePanel.add("checkbox", undefined, "Hide Original Artwork");
      chkHideOriginal.value = true;

      // --- 2. Shape Grid & Radius Callouts Panel ---
      var guidesPanel = win.add("panel", undefined, "Shape Geometry & Curvature");
      guidesPanel.orientation = "column";
      guidesPanel.alignChildren = ["left", "top"];
      guidesPanel.margins = 5;
      guidesPanel.spacing = 3;

      var rowGrid1 = guidesPanel.add("group");
      rowGrid1.spacing = 10;
      var chkCircularArcs = rowGrid1.add("checkbox", undefined, "Curvature Circles");
      chkCircularArcs.value = true;

      var chkStraightTangents = rowGrid1.add("checkbox", undefined, "Straight Edge Extended Lines");
      chkStraightTangents.value = true;

      var rowGrid2 = guidesPanel.add("group");
      rowGrid2.spacing = 10;
      var chkRadiusCallouts = rowGrid2.add("checkbox", undefined, "Curve Radius Labels (R: xx px)");
      chkRadiusCallouts.value = savedSettings.radiusCallouts !== undefined ? savedSettings.radiusCallouts : true;
      chkRadiusCallouts.graphics.foregroundColor = chkRadiusCallouts.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [0, 0.5, 0.9, 1], 1);

      var chkDimensions = rowGrid2.add("checkbox", undefined, "CAD Dimensions (W / H)");
      chkDimensions.value = false;

      var rowGuides1 = guidesPanel.add("group");
      rowGuides1.spacing = 10;
      var chkBoxGuides = rowGuides1.add("checkbox", undefined, "Bounding Box");
      chkBoxGuides.value = false;

      var chkCenterGuides = rowGuides1.add("checkbox", undefined, "Center Crosshair");
      chkCenterGuides.value = false;

      var chkNativeGuides = guidesPanel.add("checkbox", undefined, "Convert Grid to Native Illustrator Guides (Lockable)");
      chkNativeGuides.value = false;

      // --- 3. Node & Handle Display Options ---
      var nodeTogglePanel = win.add("panel", undefined, "Visibility & Color Modes");
      nodeTogglePanel.orientation = "row";
      nodeTogglePanel.alignChildren = ["left", "center"];
      nodeTogglePanel.margins = 5;
      nodeTogglePanel.spacing = 12;

      var chkDrawNodes = nodeTogglePanel.add("checkbox", undefined, "Anchor Markers");
      chkDrawNodes.value = true;

      var chkDrawHandles = nodeTogglePanel.add("checkbox", undefined, "Handle Lines");
      chkDrawHandles.value = true;

      var chkKeepFill = nodeTogglePanel.add("checkbox", undefined, "Translucent Shape Fill");
      chkKeepFill.value = true;

      var chkRainbow = nodeTogglePanel.add("checkbox", undefined, "Rainbow Multi-Object Palette");
      chkRainbow.value = false;

      // --- 4. Presets & Custom Colors ---
      var stylePanel = win.add("panel", undefined, "Preset & Custom Colors");
      stylePanel.orientation = "column";
      stylePanel.alignChildren = ["fill", "top"];
      stylePanel.margins = 5;
      stylePanel.spacing = 3;

      var presetGroup = stylePanel.add("group");
      presetGroup.add("statictext", undefined, "Theme Preset:");
      var presetDD = presetGroup.add("dropdownlist", undefined, [
        PRESETS.OUTLINER_PRO.name,
        PRESETS.LAYER_ACCENT.name,
        PRESETS.CLASSIC_BLUE.name,
        PRESETS.NEON_CYAN.name,
        PRESETS.BLUEPRINT.name,
        PRESETS.MINIMAL_DARK.name,
        PRESETS.CUSTOM.name
      ]);
      presetDD.selection = 0;

      var chkLayerColor = stylePanel.add("checkbox", undefined, "Use Layer Accent Color");
      chkLayerColor.value = true;

      var rgbGroup = stylePanel.add("group");
      rgbGroup.spacing = 5;
      rgbGroup.add("statictext", undefined, "RGB:");
      var sldR = rgbGroup.add("slider", undefined, savedSettings.r || 255, 0, 255);
      var sldG = rgbGroup.add("slider", undefined, savedSettings.g || 100, 0, 255);
      var sldB = rgbGroup.add("slider", undefined, savedSettings.b || 0, 0, 255);

      // --- 5. Geometry Sizes Panel (Minimal Defaults: 4, 4, 1, 1) ---
      var geomPanel = win.add("panel", undefined, "Sizes & Shapes");
      geomPanel.orientation = "column";
      geomPanel.alignChildren = ["fill", "top"];
      geomPanel.margins = 5;
      geomPanel.spacing = 3;

      var rowAnchor = geomPanel.add("group");
      rowAnchor.spacing = 5;
      rowAnchor.add("statictext", undefined, "Anchor:");
      var sldAnchorSize = rowAnchor.add("slider", undefined, savedSettings.anchorSize || 4, 4, 80);
      var txtAnchorSize = rowAnchor.add("edittext", undefined, (savedSettings.anchorSize || 4).toString());
      txtAnchorSize.characters = 3;

      rowAnchor.add("statictext", undefined, "Shape:");
      var ddAnchorShape = rowAnchor.add("dropdownlist", undefined, ["Square", "Circle", "Diamond", "Crosshair (+)"]);
      ddAnchorShape.selection = 0;

      var chkAnchorFilled = rowAnchor.add("checkbox", undefined, "Filled");
      chkAnchorFilled.value = false;

      var rowHandle = geomPanel.add("group");
      rowHandle.spacing = 5;
      rowHandle.add("statictext", undefined, "Handle:");
      var sldHandleSize = rowHandle.add("slider", undefined, savedSettings.handleSize || 4, 4, 80);
      var txtHandleSize = rowHandle.add("edittext", undefined, (savedSettings.handleSize || 4).toString());
      txtHandleSize.characters = 3;

      rowHandle.add("statictext", undefined, "Shape:");
      var ddHandleShape = rowHandle.add("dropdownlist", undefined, ["Circle", "Square", "Diamond"]);
      ddHandleShape.selection = 0;

      var chkDashedSticks = rowHandle.add("checkbox", undefined, "Dashed");
      chkDashedSticks.value = false;

      var rowStrokes = geomPanel.add("group");
      rowStrokes.spacing = 5;
      rowStrokes.add("statictext", undefined, "Node Stroke:");
      var sldAnchorStroke = rowStrokes.add("slider", undefined, savedSettings.anchorStroke || 1, 1, 20);
      var txtAnchorStroke = rowStrokes.add("edittext", undefined, (savedSettings.anchorStroke || 1).toString());
      txtAnchorStroke.characters = 3;

      rowStrokes.add("statictext", undefined, "Outline Stroke:");
      var sldOutlineStroke = rowStrokes.add("slider", undefined, savedSettings.outlineStroke || 1, 1, 30);
      var txtOutlineStroke = rowStrokes.add("edittext", undefined, (savedSettings.outlineStroke || 1).toString());
      txtOutlineStroke.characters = 3;

      // --- 6. Presentation Panel ---
      var presentationPanel = win.add("panel", undefined, "Portfolio Presentation");
      presentationPanel.orientation = "column";
      presentationPanel.alignChildren = ["left", "top"];
      presentationPanel.margins = 5;
      presentationPanel.spacing = 3;

      var rowPres1 = presentationPanel.add("group");
      rowPres1.spacing = 10;
      var chkShowPointIndex = rowPres1.add("checkbox", undefined, "Global Point Numbers (1...N)");
      chkShowPointIndex.value = false;

      var chkBgCard = rowPres1.add("checkbox", undefined, "Background Card");
      chkBgCard.value = false;

      var bgGroup = presentationPanel.add("group");
      bgGroup.spacing = 6;
      bgGroup.add("statictext", undefined, "Card Style:");
      var ddBgStyle = bgGroup.add("dropdownlist", undefined, ["Dark Charcoal (#1E1E24)", "CAD Blueprint Blue (#0B2545)", "Clean Pure White (#FFFFFF)"]);
      ddBgStyle.selection = 0;

      // --- 7. Automation Options Panel ---
      var advPanel = win.add("panel", undefined, "Automation & Layer Options");
      advPanel.orientation = "row";
      advPanel.alignChildren = ["left", "top"];
      advPanel.margins = 5;
      advPanel.spacing = 12;

      var chkConvertText = advPanel.add("checkbox", undefined, "Auto Text Outlines");
      chkConvertText.value = true;
      var chkGroupRelated = advPanel.add("checkbox", undefined, "Group Nodes");
      chkGroupRelated.value = true;
      var chkForceOpacity = advPanel.add("checkbox", undefined, "100% Opacity");
      chkForceOpacity.value = true;

      // --- Bottom Buttons & Footer Contact Bar ---
      var footerContainer = win.add("group");
      footerContainer.orientation = "column";
      footerContainer.alignment = ["fill", "bottom"];
      footerContainer.spacing = 8;

      var btnGroup = footerContainer.add("group");
      btnGroup.orientation = "row";
      btnGroup.alignment = ["center", "center"];
      btnGroup.spacing = 10;

      var btnRun = btnGroup.add("button", undefined, "Apply & Keep", { name: "ok" });
      var btnExport = btnGroup.add("button", undefined, "Export PNG Presentation");
      var btnCancel = btnGroup.add("button", undefined, "Cancel");

      var contactGroup = footerContainer.add("group");
      contactGroup.orientation = "row";
      contactGroup.alignment = ["center", "center"];
      contactGroup.spacing = 5;

      var lblContact = contactGroup.add("statictext", undefined, "Developed by Bido  •  Official Website: bid032.com");
      lblContact.graphics.foregroundColor = lblContact.graphics.newPen(win.graphics.PenType.SOLID_COLOR, [1, 1, 1, 1], 1);

      var triggerOpenWebsite = function () {
        openWebLink("https://bid032.com");
      };

      lblContact.onClick = triggerOpenWebsite;
      if (lblContact.addEventListener) {
        lblContact.addEventListener("mousedown", triggerOpenWebsite);
        lblContact.addEventListener("click", triggerOpenWebsite);
      }
      contactGroup.onClick = triggerOpenWebsite;

      // ------------------------------------------------------------------------
      // UI CONFIG & LIVE PREVIEW HANDLERS
      // ------------------------------------------------------------------------
      function getUIConfig() {
        var selectedPresetKey = getPresetKey(presetDD.selection.index);
        var selectedPreset = PRESETS[selectedPresetKey];
        var nodeRGB = cfgRGB(selectedPreset.anchorRGB, [Math.round(sldR.value), Math.round(sldG.value), Math.round(sldB.value)], selectedPresetKey === "CUSTOM");

        var outlineRGB = (selectedPreset && selectedPreset.outlineRGB) ? selectedPreset.outlineRGB : [80, 80, 85];

        return {
          scope: radSelected.value ? "selected" : "document",
          hideOriginal: chkHideOriginal.value,
          circularArcs: chkCircularArcs.value,
          straightTangents: chkStraightTangents.value,
          radiusCallouts: chkRadiusCallouts.value,
          dimensions: chkDimensions.value,
          boxGuides: chkBoxGuides.value,
          centerGuides: chkCenterGuides.value,
          nativeGuides: chkNativeGuides.value,
          drawNodes: chkDrawNodes.value,
          drawHandles: chkDrawHandles.value,
          keepFill: chkKeepFill.value,
          rainbow: chkRainbow.value,
          anchorSize: Math.round(sldAnchorSize.value),
          handleSize: Math.round(sldHandleSize.value),
          anchorStrokeWidth: Math.round(sldAnchorStroke.value),
          outlineWidth: Math.round(sldOutlineStroke.value),
          anchorShape: ddAnchorShape.selection.text,
          handleShape: ddHandleShape.selection.text,
          dashedSticks: chkDashedSticks.value,
          anchorIsFilled: chkAnchorFilled.value,
          useLayerColor: chkLayerColor.value,
          presetRGB: nodeRGB,
          outlineRGB: outlineRGB,
          showIndexLabels: chkShowPointIndex.value,
          createBgCard: chkBgCard.value,
          bgStyle: ddBgStyle.selection.index,
          convertText: chkConvertText.value,
          groupRelated: chkGroupRelated.value,
          forceOpacity: chkForceOpacity.value
        };
      }

      function triggerLivePreview() {
        if (chkLivePreview.value) {
          var stats = renderPreviewLayer(getUIConfig());
          if (stats) {
            lblStats.text = "Paths: " + stats.paths + "  |  Anchors: " + stats.anchors + "  |  Handles: " + stats.handles;
          }
          app.redraw();
        }
      }

      // Bind Controls
      bindSliderTextPair(sldAnchorSize, txtAnchorSize, triggerLivePreview);
      bindSliderTextPair(sldHandleSize, txtHandleSize, triggerLivePreview);
      bindSliderTextPair(sldAnchorStroke, txtAnchorStroke, triggerLivePreview);
      bindSliderTextPair(sldOutlineStroke, txtOutlineStroke, triggerLivePreview);

      sldR.onChanging = triggerLivePreview;
      sldG.onChanging = triggerLivePreview;
      sldB.onChanging = triggerLivePreview;

      presetDD.onChange = function () {
        var isCustom = (presetDD.selection.index === 6);
        chkLayerColor.value = (presetDD.selection.index === 1);
        rgbGroup.enabled = isCustom;
        triggerLivePreview();
      };

      chkCircularArcs.onClick = triggerLivePreview;
      chkStraightTangents.onClick = triggerLivePreview;
      chkRadiusCallouts.onClick = triggerLivePreview;
      chkDimensions.onClick = triggerLivePreview;
      chkBoxGuides.onClick = triggerLivePreview;
      chkCenterGuides.onClick = triggerLivePreview;
      chkNativeGuides.onClick = triggerLivePreview;

      chkDrawNodes.onClick = triggerLivePreview;
      chkDrawHandles.onClick = triggerLivePreview;
      chkRainbow.onClick = triggerLivePreview;

      chkLayerColor.onClick = triggerLivePreview;
      ddAnchorShape.onChange = triggerLivePreview;
      ddHandleShape.onChange = triggerLivePreview;
      chkDashedSticks.onClick = triggerLivePreview;
      chkAnchorFilled.onClick = triggerLivePreview;
      radSelected.onClick = triggerLivePreview;
      radEntireDoc.onClick = triggerLivePreview;
      chkShowPointIndex.onClick = triggerLivePreview;
      chkBgCard.onClick = triggerLivePreview;
      ddBgStyle.onChange = triggerLivePreview;
      chkConvertText.onClick = triggerLivePreview;
      chkGroupRelated.onClick = triggerLivePreview;
      chkForceOpacity.onClick = triggerLivePreview;

      chkLivePreview.onClick = function () {
        if (!chkLivePreview.value) {
          removePreviewLayer();
          lblStats.text = "Preview Disabled";
          app.redraw();
        } else {
          triggerLivePreview();
        }
      };

      btnRun.onClick = function () {
        saveUserSettings(getUIConfig());
        win.close();
      };

      btnExport.onClick = function () {
        var cfg = getUIConfig();
        saveUserSettings(cfg);
        triggerLivePreview();
        exportPNGAndRevert();
        win.close();
      };

      btnCancel.onClick = function () {
        removePreviewLayer();
        app.redraw();
        win.close();
      };

      if (chkLivePreview.value) {
        triggerLivePreview();
      }

      win.show();
    }

    function bindSliderTextPair(slider, textInput, callback) {
      slider.onChanging = function () {
        textInput.text = Math.round(slider.value).toString();
        callback();
      };
      slider.onChange = function () {
        textInput.text = Math.round(slider.value).toString();
        callback();
      };
      textInput.onChange = function () {
        var val = parseFloat(textInput.text);
        if (!isNaN(val)) {
          slider.value = Math.min(Math.max(val, slider.minvalue), slider.maxvalue);
          callback();
        }
      };
    }

    function getPresetKey(index) {
      var keys = ["OUTLINER_PRO", "LAYER_ACCENT", "CLASSIC_BLUE", "NEON_CYAN", "BLUEPRINT", "MINIMAL_DARK", "CUSTOM"];
      return keys[index] || "OUTLINER_PRO";
    }

    function cfgRGB(presetRGB, customRGB, isCustom) {
      return isCustom ? customRGB : presetRGB;
    }

    // ============================================================================
    // PREVIEW & ANTI-COLLISION ENGINE
    // ============================================================================
    function restoreHiddenOriginals() {
      if (typeof hiddenOriginals === "undefined" || !hiddenOriginals) {
        hiddenOriginals = [];
        return;
      }
      for (var i = 0; i < hiddenOriginals.length; i++) {
        try {
          if (hiddenOriginals[i] && hiddenOriginals[i].hidden !== undefined) {
            hiddenOriginals[i].hidden = false;
          }
        } catch (e) { }
      }
      hiddenOriginals = [];
    }

    function removePreviewLayer() {
      restoreHiddenOriginals();
      try {
        var existingLayer = doc.layers.getByName(PREVIEW_LAYER_NAME);
        existingLayer.remove();
      } catch (e) { }
    }

    function renderPreviewLayer(cfg) {
      removePreviewLayer();

      var previewLayer = doc.layers.add();
      previewLayer.name = PREVIEW_LAYER_NAME;

      // Scan targets FIRST before setting hidden = true!
      var pathList = scanTargetItems(cfg, previewLayer);
      if (pathList.length === 0) return { paths: 0, anchors: 0, handles: 0 };

      var topTargets = getTopLevelTargets(cfg);
      var pRGB = (cfg && cfg.presetRGB) ? cfg.presetRGB : [25, 25, 30];
      var oRGB = (cfg && cfg.outlineRGB) ? cfg.outlineRGB : [80, 80, 85];
      var defaultAnchorColor = createRGB(pRGB[0], pRGB[1], pRGB[2]);
      var defaultOutlineColor = createRGB(oRGB[0], oRGB[1], oRGB[2]);

      // Render top-level compound silhouettes with preserved holes if keepFill is enabled
      if (cfg.keepFill) {
        for (var f = 0; f < topTargets.length; f++) {
          try {
            var fillClone = topTargets[f].duplicate(previewLayer, ElementPlacement.PLACEATEND);
            fillClone.hidden = false;
            fillClone.opacity = 15;
            setSubtreeStrokeAndFill(fillClone, defaultOutlineColor, cfg.outlineWidth);
          } catch (errFill) { }
        }
      }

      // Hide original artwork AFTER scanning and cloning
      if (cfg.hideOriginal) {
        for (var k = 0; k < topTargets.length; k++) {
          var tItem = topTargets[k];
          if (tItem.layer && tItem.layer.name !== PREVIEW_LAYER_NAME && !tItem.hidden) {
            tItem.hidden = true;
            hiddenOriginals.push(tItem);
          }
        }
      }

      // Tracker array for collision avoidance
      var placedTextBounds = [];

      if (cfg.createBgCard) {
        drawBackgroundCard(previewLayer, cfg.bgStyle);
      }

      var defaultAnchorColor = createRGB(cfg.presetRGB[0], cfg.presetRGB[1], cfg.presetRGB[2]);
      var defaultOutlineColor = createRGB(cfg.outlineRGB[0], cfg.outlineRGB[1], cfg.outlineRGB[2]);

      var totalAnchors = 0;
      var totalHandles = 0;

      var totalBounds = getCombinedBounds(pathList);

      // Technical CAD Dimensions (Width / Height px)
      if (cfg.dimensions) {
        drawCADDimensions(previewLayer, totalBounds, defaultAnchorColor, cfg.nativeGuides, placedTextBounds);
      }

      // Shape Construction Grid (Curvature Circles, Tangents & Radius Callouts)
      if (cfg.circularArcs || cfg.straightTangents || cfg.boxGuides || cfg.centerGuides || cfg.radiusCallouts) {
        drawShapeConstructionGrid(previewLayer, pathList, totalBounds, cfg, defaultAnchorColor, placedTextBounds);
      }

      // Global Continuous Anchor Point Counter (1...N)
      var globalAnchorCounter = 1;

      // Render Path Outlines and Node Markers
      for (var i = pathList.length - 1; i >= 0; i--) {
        var target = pathList[i];
        var item = target.item || target;
        var isText = target.isText || false;
        if (!item || item.typename !== "PathItem") continue;

        var activeNodeColor = defaultAnchorColor;
        if (cfg.rainbow) {
          var pal = RAINBOW_PALETTE[i % RAINBOW_PALETTE.length];
          activeNodeColor = createRGB(pal[0], pal[1], pal[2]);
        } else if (cfg.useLayerColor) {
          activeNodeColor = item.layer.color;
        }

        var pathClone = item.duplicate(previewLayer, ElementPlacement.PLACEATEND);
        pathClone.hidden = false;
        pathClone.filled = false;
        pathClone.stroked = true;
        pathClone.strokeWidth = cfg.outlineWidth;
        pathClone.strokeColor = cfg.rainbow ? activeNodeColor : defaultOutlineColor;

        // Skip anchor markers and handle lines for text glyphs to maintain crisp typography
        if (isText) continue;

        var parentGroup = null;
        if (cfg.groupRelated) {
          parentGroup = previewLayer.groupItems.add();
          parentGroup.name = (item.name || "Path") + "_Nodes";
        }

        if (item.pathPoints && item.pathPoints.length) {
          totalAnchors += item.pathPoints.length;

          for (var p = 0; p < item.pathPoints.length; p++) {
            var point = item.pathPoints[p];
            var pointName = (item.name || "Point") + "[" + p + "]";
            var pointGroup = cfg.groupRelated ? parentGroup.groupItems.add() : null;
            if (pointGroup) pointGroup.name = pointName;

            var destGroup = pointGroup || previewLayer;

            if (cfg.drawNodes) {
              drawAnchorShape(
                destGroup,
                point.anchor,
                cfg.anchorSize,
                cfg.anchorShape,
                cfg.anchorStrokeWidth,
                activeNodeColor,
                cfg.anchorIsFilled
              );
            }

            // Anti-Collision Global Continuous Numbering (1...N)
            if (cfg.showIndexLabels) {
              var initialPos = [point.anchor[0] + (cfg.anchorSize / 2) + 4, point.anchor[1] + (cfg.anchorSize / 2) + 8];
              var resolvedPos = resolveAntiCollisionPosition(initialPos, 14, 12, placedTextBounds);

              drawHaloTextLabel(
                destGroup,
                resolvedPos,
                globalAnchorCounter.toString(),
                activeNodeColor,
                10,
                placedTextBounds
              );
            }
            globalAnchorCounter++;

            if (cfg.drawHandles) {
              var hLeft = drawHandle(destGroup, point, "left", cfg.handleSize, cfg.handleShape, cfg.anchorStrokeWidth, activeNodeColor, cfg.dashedSticks);
              var hRight = drawHandle(destGroup, point, "right", cfg.handleSize, cfg.handleShape, cfg.anchorStrokeWidth, activeNodeColor, cfg.dashedSticks);

              if (hLeft) totalHandles++;
              if (hRight) totalHandles++;
            }
          }
        }
      }

      return {
        paths: pathList.length,
        anchors: totalAnchors,
        handles: totalHandles
      };
    }

    // ============================================================================
    // ANTI-COLLISION & WHITE VECTOR HALO GLOW ENGINE
    // ============================================================================

    function resolveAntiCollisionPosition(basePos, widthEstimate, heightEstimate, boundsList) {
      var candidates = [
        [basePos[0], basePos[1]],                          // Original Top-Right
        [basePos[0] - widthEstimate - 8, basePos[1]],      // Top-Left
        [basePos[0], basePos[1] - heightEstimate - 8],     // Bottom-Right
        [basePos[0] - widthEstimate - 8, basePos[1] - heightEstimate - 8], // Bottom-Left
        [basePos[0] + 6, basePos[1] + 12],                // Higher Top-Right
        [basePos[0] - widthEstimate - 12, basePos[1] + 12] // Higher Top-Left
      ];

      for (var c = 0; c < candidates.length; c++) {
        var cand = candidates[c];
        var candBox = [cand[0], cand[1], cand[0] + widthEstimate, cand[1] - heightEstimate];
        var isOverlap = false;

        for (var b = 0; b < boundsList.length; b++) {
          var existing = boundsList[b];
          // Check AABB collision with 3px padding
          if (candBox[0] < existing[2] + 3 && candBox[2] > existing[0] - 3 &&
            candBox[1] > existing[3] - 3 && candBox[3] < existing[1] + 3) {
            isOverlap = true;
            break;
          }
        }

        if (!isOverlap) return cand;
      }

      // Default fallback
      return basePos;
    }

    function drawHaloTextLabel(container, position, textStr, textColor, fontSize, boundsList) {
      try {
        var fontSz = fontSize || 10;

        // Clean Colored Text Frame (No White Stroke / Halo)
        var tf = container.textFrames.add();
        tf.contents = textStr;
        tf.position = position;
        tf.textRange.characterAttributes.size = fontSz;
        tf.textRange.characterAttributes.fillColor = textColor;
        tf.textRange.characterAttributes.stroked = false;

        // Record bounding box for collision engine
        var b = tf.geometricBounds; // [left, top, right, bottom]
        if (boundsList && b) {
          boundsList.push([b[0], b[1], b[2], b[3]]);
        }
      } catch (e) { }
    }

    function drawCADDimensions(container, bounds, color, makeNative, boundsList) {
      var dimGroup = container.groupItems.add();
      dimGroup.name = "_CAD_Dimensions";

      var left = bounds[0], top = bounds[1], right = bounds[2], bottom = bounds[3];
      var width = right - left;
      var height = top - bottom;
      var offset = 35;

      // Width Callout
      var wLine = dimGroup.pathItems.add();
      wLine.setEntirePath([[left, top + offset], [right, top + offset]]);
      applyGuideStyle(wLine, color, makeNative);

      var wTick1 = dimGroup.pathItems.add();
      wTick1.setEntirePath([[left - 5, top + offset - 5], [left + 5, top + offset + 5]]);
      applyGuideStyle(wTick1, color, makeNative);

      var wTick2 = dimGroup.pathItems.add();
      wTick2.setEntirePath([[right - 5, top + offset - 5], [right + 5, top + offset + 5]]);
      applyGuideStyle(wTick2, color, makeNative);

      drawHaloTextLabel(dimGroup, [left + (width / 2) - 25, top + offset + 14], "W: " + Math.round(width * 10) / 10 + " px", color, 11, boundsList);

      // Height Callout
      var hLine = dimGroup.pathItems.add();
      hLine.setEntirePath([[right + offset, top], [right + offset, bottom]]);
      applyGuideStyle(hLine, color, makeNative);

      var hTick1 = dimGroup.pathItems.add();
      hTick1.setEntirePath([[right + offset - 5, top + 5], [right + offset + 5, top - 5]]);
      applyGuideStyle(hTick1, color, makeNative);

      var hTick2 = dimGroup.pathItems.add();
      hTick2.setEntirePath([[right + offset - 5, bottom + 5], [right + offset + 5, bottom - 5]]);
      applyGuideStyle(hTick2, color, makeNative);

      drawHaloTextLabel(dimGroup, [right + offset + 10, bottom + (height / 2) + 4], "H: " + Math.round(height * 10) / 10 + " px", color, 11, boundsList);
    }

    function drawBrandingHeader(container, bounds, color, creditText) {
      try {
        var left = bounds[0] - 100;
        var top = bounds[1] + 90;

        var header = container.textFrames.add();
        header.contents = creditText || "Designed by Bido | bid032.com";
        header.position = [left, top];
        header.textRange.characterAttributes.size = 13;
        header.textRange.characterAttributes.fillColor = color;
      } catch (e) { }
    }

    // ============================================================================
    // REFINED SHAPE GEOMETRY & RADIUS CALLOUT ENGINE
    // ============================================================================
    function drawShapeConstructionGrid(container, pathList, bounds, cfg, guideColor, boundsList) {
      var gridGroup = container.groupItems.add();
      gridGroup.name = "_Shape_Construction_Grid";

      var left = bounds[0], top = bounds[1], right = bounds[2], bottom = bounds[3];
      var width = right - left, height = top - bottom;
      var maxDim = Math.max(width, height);
      var extensionLen = Math.max(maxDim * 2.5, 1500);

      var drawnCirclesCache = [];

      for (var i = 0; i < pathList.length; i++) {
        var target = pathList[i];
        var item = target.item || target;
        var isText = target.isText || false;

        // CRITICAL FIX: Skip text glyph outlines from generating construction grid circles & tangent lines
        if (isText) continue;

        if (item.pathPoints && item.pathPoints.length >= 2) {
          var pts = item.pathPoints;
          var count = item.closed ? pts.length : pts.length - 1;

          for (var p = 0; p < count; p++) {
            var currPt = pts[p];
            var nextPt = pts[(p + 1) % pts.length];

            var p0 = currPt.anchor;
            var p1 = currPt.rightDirection;
            var p2 = nextPt.leftDirection;
            var p3 = nextPt.anchor;

            var isCurved = (Number(p0[0]) !== Number(p1[0]) || Number(p0[1]) !== Number(p1[1]) ||
              Number(p3[0]) !== Number(p2[0]) || Number(p3[1]) !== Number(p2[1]));

            if (isCurved && cfg.circularArcs) {
              var mid = getBezierMidPoint(p0, p1, p2, p3);
              drawCircumcircleForArcDeduplicated(
                gridGroup, p0, mid, p3, guideColor, cfg.nativeGuides, cfg.radiusCallouts, drawnCirclesCache, boundsList
              );
            } else if (!isCurved && cfg.straightTangents) {
              createAngledExtensionLine(gridGroup, p0, p3, extensionLen, guideColor, cfg.nativeGuides);
            }
          }
        }
      }

      if (cfg.boxGuides) {
        var box = gridGroup.pathItems.rectangle(top + 10, left - 10, width + 20, height + 20);
        applyGuideStyle(box, guideColor, cfg.nativeGuides);
      }

      if (cfg.centerGuides) {
        var centerX = left + (width / 2);
        var centerY = bottom + (height / 2);
        var pad = 60;

        var hCenterLine = gridGroup.pathItems.add();
        hCenterLine.setEntirePath([[left - pad, centerY], [right + pad, centerY]]);
        applyGuideStyle(hCenterLine, guideColor, cfg.nativeGuides);

        var vCenterLine = gridGroup.pathItems.add();
        vCenterLine.setEntirePath([[centerX, top + pad], [centerX, bottom - pad]]);
        applyGuideStyle(vCenterLine, guideColor, cfg.nativeGuides);
      }
    }

    function getBezierMidPoint(p0, p1, p2, p3) {
      var t = 0.5, u = 1 - t;
      var tt = t * t, uu = u * u;
      var uuu = uu * u, ttt = tt * t;

      var x = uuu * p0[0] + 3 * uu * t * p1[0] + 3 * u * tt * p2[0] + ttt * p3[0];
      var y = uuu * p0[1] + 3 * uu * t * p1[1] + 3 * u * tt * p2[1] + ttt * p3[1];
      return [x, y];
    }

    function drawCircumcircleForArcDeduplicated(container, A, B, C, color, makeNative, showRadiusLabel, cache, boundsList) {
      var x1 = A[0], y1 = A[1];
      var x2 = B[0], y2 = B[1];
      var x3 = C[0], y3 = C[1];

      var D = 2 * (x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2));
      if (Math.abs(D) < 0.001) return;

      var sq1 = x1 * x1 + y1 * y1;
      var sq2 = x2 * x2 + y2 * y2;
      var sq3 = x3 * x3 + y3 * y3;

      var Ux = (sq1 * (y2 - y3) + sq2 * (y3 - y1) + sq3 * (y1 - y2)) / D;
      var Uy = (sq1 * (x3 - x2) + sq2 * (x1 - x3) + sq3 * (x2 - x1)) / D;

      var radius = Math.sqrt((x1 - Ux) * (x1 - Ux) + (y1 - Uy) * (y1 - Uy));

      if (radius > 0.5 && radius < 4000) {
        // Deduplication check for circles
        for (var i = 0; i < cache.length; i++) {
          var c = cache[i];
          if (Math.abs(c.x - Ux) < 2.0 && Math.abs(c.y - Uy) < 2.0 && Math.abs(c.r - radius) < 2.0) {
            return;
          }
        }
        cache.push({ x: Ux, y: Uy, r: radius });

        var circle = container.pathItems.ellipse(Uy + radius, Ux - radius, radius * 2, radius * 2);
        applyGuideStyle(circle, color, makeNative);

        // Render Anti-Collision Halo Radius Label
        if (showRadiusLabel && radius > 15) {
          var initialPos = [Ux - 15, Uy + 5];
          var resolvedPos = resolveAntiCollisionPosition(initialPos, 45, 10, boundsList);
          drawHaloTextLabel(container, resolvedPos, "R: " + Math.round(radius * 10) / 10 + " px", color, 9, boundsList);
        }
      }
    }

    function createAngledExtensionLine(container, p1, p2, extLen, color, makeNative) {
      var dx = p2[0] - p1[0];
      var dy = p2[1] - p1[1];
      var dist = Math.sqrt(dx * dx + dy * dy);

      if (dist < 0.1) return;

      var uX = dx / dist;
      var uY = dy / dist;

      var startX = p1[0] - (uX * extLen);
      var startY = p1[1] - (uY * extLen);
      var endX = p2[0] + (uX * extLen);
      var endY = p2[1] + (uY * extLen);

      var guideLine = container.pathItems.add();
      guideLine.setEntirePath([[startX, startY], [endX, endY]]);
      applyGuideStyle(guideLine, color, makeNative);
    }

    function applyGuideStyle(item, color, makeNative) {
      if (makeNative) {
        item.guides = true;
      } else {
        item.filled = false;
        item.stroked = true;
        item.strokeWidth = 0.5;
        item.strokeColor = color;
        item.opacity = 55;
      }
    }

    function getCombinedBounds(pathList) {
      var left = Infinity, top = -Infinity, right = -Infinity, bottom = Infinity;
      for (var i = 0; i < pathList.length; i++) {
        var target = pathList[i];
        var item = target.item || target;
        if (!item || !item.visibleBounds) continue;
        var b = item.visibleBounds;
        if (b[0] < left) left = b[0];
        if (b[1] > top) top = b[1];
        if (b[2] > right) right = b[2];
        if (b[3] < bottom) bottom = b[3];
      }
      if (left === Infinity) return [-200, 200, 200, -200];
      return [left, top, right, bottom];
    }

    // ============================================================================
    // USER PREFERENCE MEMORY (SAVE / LOAD)
    // ============================================================================
    function saveUserSettings(cfg) {
      try {
        var file = new File(SETTINGS_FILE_PATH);
        file.open("w");
        file.writeln("anchorSize=" + cfg.anchorSize);
        file.writeln("handleSize=" + cfg.handleSize);
        file.writeln("anchorStroke=" + cfg.anchorStrokeWidth);
        file.writeln("outlineStroke=" + cfg.outlineWidth);
        file.writeln("radiusCallouts=" + cfg.radiusCallouts);
        file.writeln("r=" + cfg.presetRGB[0]);
        file.writeln("g=" + cfg.presetRGB[1]);
        file.writeln("b=" + cfg.presetRGB[2]);
        file.close();
      } catch (e) { }
    }

    function loadUserSettings() {
      var settings = {};
      try {
        var file = new File(SETTINGS_FILE_PATH);
        if (file.exists) {
          file.open("r");
          while (!file.eof) {
            var line = file.readln();
            var parts = line.split("=");
            if (parts.length === 2) {
              var key = parts[0];
              var val = parts[1];
              if (val === "true") val = true;
              else if (val === "false") val = false;
              else if (!isNaN(parseFloat(val))) val = parseFloat(val);
              settings[key] = val;
            }
          }
          file.close();
        }
      } catch (e) { }
      return settings;
    }

    // ============================================================================
    // PRESENTATION & DRAWING HELPERS
    // ============================================================================
    function drawBackgroundCard(container, styleIndex) {
      var bounds = doc.pageItems.length > 0 ? doc.visibleBounds : [-500, 500, 500, -500];
      var margin = 140;
      var left = bounds[0] - margin;
      var top = bounds[1] + margin;
      var width = (bounds[2] - bounds[0]) + (margin * 2);
      var height = (bounds[1] - bounds[3]) + (margin * 2);

      var card = container.pathItems.rectangle(top, left, width, height);
      card.stroked = false;
      card.filled = true;

      if (styleIndex === 1) {
        card.fillColor = createRGB(11, 37, 69);
      } else if (styleIndex === 2) {
        card.fillColor = createRGB(255, 255, 255);
      } else {
        card.fillColor = createRGB(30, 30, 36);
      }

      card.zOrder(ZOrderMethod.SENDTOBACK);
    }

    function getTopLevelTargets(cfg) {
      var targets = [];
      if (cfg.scope === "selected" && doc.selection && doc.selection.length > 0) {
        for (var i = 0; i < doc.selection.length; i++) {
          if (doc.selection[i].layer && doc.selection[i].layer.name !== PREVIEW_LAYER_NAME) {
            targets.push(doc.selection[i]);
          }
        }
      } else {
        for (var l = 0; l < doc.layers.length; l++) {
          var lyr = doc.layers[l];
          if (lyr.name !== PREVIEW_LAYER_NAME && lyr.visible) {
            for (var p = 0; p < lyr.pageItems.length; p++) {
              targets.push(lyr.pageItems[p]);
            }
          }
        }
      }
      return targets;
    }

    function setSubtreeStrokeAndFill(item, strokeColor, strokeWidth) {
      if (!item) return;
      if (item.typename === "TextFrame") {
        try {
          var outlined = item.createOutline();
          setSubtreeStrokeAndFill(outlined, strokeColor, strokeWidth);
        } catch (e) { }
      } else if (item.typename === "PathItem" || item.typename === "CompoundPathItem") {
        item.stroked = true;
        item.strokeColor = strokeColor;
        item.strokeWidth = strokeWidth;
      } else if (item.typename === "GroupItem") {
        for (var i = 0; i < item.pageItems.length; i++) {
          setSubtreeStrokeAndFill(item.pageItems[i], strokeColor, strokeWidth);
        }
      }
    }

    function scanTargetItems(cfg, previewLayer) {
      var list = [];
      if (cfg.scope === "selected" && doc.selection && doc.selection.length > 0) {
        collectPathsRecursively(doc.selection, list, cfg.convertText, previewLayer, false);
      } else {
        for (var i = doc.pathItems.length - 1; i >= 0; i--) {
          if (doc.pathItems[i].layer.name !== PREVIEW_LAYER_NAME) {
            list.push({ item: doc.pathItems[i], isText: false });
          }
        }
        if (cfg.convertText && previewLayer) {
          for (var t = doc.textFrames.length - 1; t >= 0; t--) {
            var tf = doc.textFrames[t];
            if (tf.layer.name !== PREVIEW_LAYER_NAME) {
              try {
                var tfClone = tf.duplicate(previewLayer, ElementPlacement.PLACEATEND);
                var outlinedGroup = tfClone.createOutline();
                collectPathsRecursively([outlinedGroup], list, false, previewLayer, true);
              } catch (e) { }
            }
          }
        }
      }
      return list;
    }

    function collectPathsRecursively(items, list, convertText, previewLayer, isText) {
      for (var i = 0; i < items.length; i++) {
        var item = items[i];
        if (!item) continue;
        if (item.layer && item.layer.name === PREVIEW_LAYER_NAME) continue;

        if (item.typename === "PathItem") {
          list.push({ item: item, isText: isText || false });
        } else if (item.typename === "GroupItem") {
          collectPathsRecursively(item.pageItems, list, convertText, previewLayer, isText);
        } else if (item.typename === "CompoundPathItem") {
          collectPathsRecursively(item.pathItems, list, convertText, previewLayer, isText);
        } else if (item.typename === "TextFrame" && convertText !== false && previewLayer) {
          try {
            var tfClone = item.duplicate(previewLayer, ElementPlacement.PLACEATEND);
            var outlinedGroup = tfClone.createOutline();
            collectPathsRecursively([outlinedGroup], list, false, previewLayer, true);
          } catch (e) { }
        }
      }
    }

    function drawAnchorShape(container, pos, size, shapeType, strokeWidth, color, isFilled) {
      var x = pos[0];
      var y = pos[1];
      var half = size / 2;
      var item = null;

      if (shapeType === "Circle") {
        item = container.pathItems.ellipse(y + half, x - half, size, size);
      } else if (shapeType === "Diamond") {
        item = container.pathItems.add();
        item.setEntirePath([[x, y + half], [x + half, y], [x, y - half], [x - half, y]]);
        item.closed = true;
      } else if (shapeType === "Crosshair (+)") {
        var line1 = container.pathItems.add();
        line1.setEntirePath([[x - half, y], [x + half, y]]);
        applyStrokeProps(line1, strokeWidth, color, false);

        var line2 = container.pathItems.add();
        line2.setEntirePath([[x, y - half], [x, y + half]]);
        applyStrokeProps(line2, strokeWidth, color, false);
        return;
      } else {
        item = container.pathItems.rectangle(y + half, x - half, size, size);
      }

      if (item) {
        if (isFilled) {
          item.filled = true;
          item.fillColor = color;
          item.stroked = false;
        } else {
          applyStrokeProps(item, strokeWidth, color, false);
        }
      }
    }

    function drawHandle(container, point, direction, handleSize, handleShape, strokeWidth, color, isDashed) {
      var anchor = point.anchor;
      var dirPoint = point[direction + "Direction"];

      if (Number(anchor[0]) !== Number(dirPoint[0]) || Number(anchor[1]) !== Number(dirPoint[1])) {
        var stick = container.pathItems.add();
        stick.setEntirePath([anchor, dirPoint]);
        applyStrokeProps(stick, strokeWidth, color, isDashed);

        var x = dirPoint[0];
        var y = dirPoint[1];
        var half = handleSize / 2;
        var tip = null;

        if (handleShape === "Square") {
          tip = container.pathItems.rectangle(y + half, x - half, handleSize, handleSize);
        } else if (handleShape === "Diamond") {
          tip = container.pathItems.add();
          tip.setEntirePath([[x, y + half], [x + half, y], [x, y - half], [x - half, y]]);
          tip.closed = true;
        } else {
          tip = container.pathItems.ellipse(y + half, x - half, handleSize, handleSize);
        }

        if (tip) {
          tip.filled = true;
          tip.fillColor = color;
          tip.stroked = false;
        }

        return true;
      }
      return false;
    }

    function applyStrokeProps(item, strokeWidth, color, isDashed) {
      item.filled = false;
      item.stroked = true;
      item.strokeWidth = strokeWidth;
      item.strokeColor = color;
      if (isDashed) {
        item.strokeDashed = true;
        item.strokeDashArray = [4, 4];
      }
    }

    function createRGB(r, g, b) {
      var c = new RGBColor();
      c.red = r;
      c.green = g;
      c.blue = b;
      return c;
    }

    function exportPNGAndRevert() {
      try {
        var docFolderPath = null;
        try {
          if (doc.path && doc.path.fsName && doc.path.fsName !== "") {
            docFolderPath = doc.path;
          }
        } catch (e) {
          docFolderPath = null;
        }

        // If the file has NEVER been saved to disk (e.g. Untitled-1)
        if (!docFolderPath) {
          alert("هذا الملف جديد ولم يتم حفظه على الجهاز بعد!\nيرجى حفظ ملف الإليستريتور في مجلد المشروع أولاً ليتم تصدير الصورة بجانبه.");
          try {
            app.execMenuValue("save");
          } catch (errSave) { }

          try {
            if (doc.path && doc.path.fsName && doc.path.fsName !== "") {
              docFolderPath = doc.path;
            } else {
              return; // User cancelled save dialog
            }
          } catch (errCheck) {
            return;
          }
        }

        var baseName = doc.name.replace(/\.[^\.]+$/, "");
        var fileSpec = new File(docFolderPath + "/" + baseName + "_OutlinerProcess.png");

        var options = new ExportOptionsPNG24();
        options.antiAliasing = true;
        options.transparency = false;
        options.artBoardClipping = true;

        doc.exportFile(fileSpec, ExportType.PNG24, options);
        alert("تم تصدير صورة العرض بنجاح في نفس مجلد الملف:\n" + fileSpec.fsName);
        removePreviewLayer();
      } catch (e) {
        alert("Export failed: " + e.message);
      }
    }

    function openWebLink(url) {
      try {
        if (Folder.fs === "Windows") {
          system.callSystem('cmd /c start "" "' + url + '"');
        } else {
          system.callSystem('open "' + url + '"');
        }
      } catch (e) {
        try { app.openURL(url); } catch (err) { }
      }
    }
  })();
